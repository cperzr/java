/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RepasoTrimestre1Parte1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeMap;
import javax.swing.filechooser.FileSystemView;

/**
 * #Recorrido de archivos       Hecho
 * #Escritura de archivos       Hecho
 * #Crear indice                Hecho
 * #Escribir indice             Mas o Menos
 * #Leer indice                 Por Hacer
 * @author Christian
 */
public class LocalizarFicheros2 {

    static LocalizarFicheros2 ob = new LocalizarFicheros2();
    static File indice;
    

    //esto iria quitado
    static File f = new File("C:\\Users\\Christian\\Desktop\\prue");

    public static void main(String args[]) {
        ob.iniciar();
        ob.muestra();
        ob.escribe();
    }

    public void iniciar() {
        String archivo;
        File busca;

        //miramos siempre que los dos primeros tienen que ser la llamada a [java localizarficheros]
//        if (args[0].equals("java") && args[1].equals("LocalizarFicheros2")) {
//            if (!args[2].equals("-g") || !args[2].equals("-c")) {
//                try {
//                    throw new NumeroArgumentosException(mostrarAyuda());
//                } catch (NumeroArgumentosException e) {
//                    e.getMessage();
//                }
//                //miramos que argumento es el que nos ha dado
//            } else if (args[2].equals("-g")) {
//                //si es distinto de 4 no seguimos porque ha sido erroneo
//                if (args.length != 4) {
//                    try {
//                        throw new NumeroArgumentosException(mostrarAyuda());
//                    } catch (NumeroArgumentosException e) {
//                        e.getMessage();
//                    }
//                } else {
//                    //vamos a mirar si el fichero existe
//                    //File f = new File(args[3]);//asigno la ruta que ha introducido el usuario+++++++++++++++++++++++++
//                    //si es directorio hacemos el indice y lo poblaremos
        if (f.isDirectory()) {

            //---------creo el archivo [nombre].ind en el escritorio del usuario------------------
            File home = FileSystemView.getFileSystemView().getHomeDirectory();
            String dir = home.getAbsolutePath();
            String barra = System.getProperty("file.separator");
            String nombre = f.getName();//args[3];
            nombre = nombre.replace(barra, "_");
            String comprueba = dir + barra + nombre;//en el escritorio creamos el archivo indice

            indice = new File("C:\\Users\\Christian\\Desktop\\cosasE.ind");
            //indice = new File("C:\\Users\\Christian\\Desktop\\cosasE.txt");
            //--------------- fin de la creacion del archivo .ind en el escritorio-----------------

            //System.out.println("El directorio contiene los siguientes archivos");
            //para ordenar y poblar los indices
//            conArrayList(f);
        } else {//por si es un fichero o no lo encuentra
            //System.out.println("El nombre del fichero es " + f.getName());
            try {
                throw new NumeroArgumentosException(mostrarAyuda());
            } catch (NumeroArgumentosException e) {
                e.getMessage();
            }
        }
//                }
//            } else if (args[2].equals("-c")) {
//                if (args.length != 5) {
//
//                } else {
//                    archivo = args[3];
//                    busca = new File(args[4]);
//
//                    lee(archivo, busca);
//                }
//            } else {
//                try {
//                    throw new NumeroArgumentosException(mostrarAyuda());
//                } catch (NumeroArgumentosException e) {
//                    e.getMessage();
//                }
//            }
//        } else {
//            try {
//                throw new NumeroArgumentosException(mostrarAyuda());
//            } catch (NumeroArgumentosException e) {
//                e.getMessage();
//            }
//        }

        conArrayList(f);
    }

    private static String mostrarAyuda() {
        return "Para usar el comando, se usa: java LocalizarFicheros [-g]/[-c] [rutaDelDirectorio]/[archivo documento.ind]";
    }

    private static void lee(String archivo, File busca) {

        String barra = System.getProperty("file.separator");
        try {

            FileReader fr = new FileReader(busca);//objeto de lectura
            BufferedReader BR = new BufferedReader(fr);
            String linea;
            while ((linea = BR.readLine()) != null) {
                boolean extencion = false;
                boolean nom = false;

                int extb = archivo.lastIndexOf(".");
                String EXTN = archivo.substring(extb, archivo.length());

                int nomb = archivo.lastIndexOf(barra);
                String NOMB = archivo.substring(nomb, archivo.lastIndexOf("."));

                if (EXTN.equals(linea.substring(linea.lastIndexOf("."), linea.length()))) {
                    extencion = true;
                } else {
                    extencion = false;
                }
                if (NOMB.equals(linea.substring(linea.lastIndexOf(barra), linea.lastIndexOf(".")))) {
                    nom = true;
                } else {
                    nom = false;
                }

                if (extencion == true && nom == true) {
                    File arch = new File(linea.substring(0, linea.lastIndexOf(barra)));
                    System.out.println(linea);
                }
            }

            BR.close();
            fr.close();
        } catch (IOException e) {
        }
    }
    public static ArrayList<File> directorios = new ArrayList();
    public static ArrayList<File> archivos = new ArrayList();
    public static ArrayList<String> resumenRutas = new ArrayList();

    private void conArrayList(File f) {

        File[] lista = f.listFiles();

        for (File file : lista) {
            try {
                if (file.isFile()) {
                    
                    archivos.add(file.getAbsoluteFile());
                } else if (file.isDirectory()) {
                    directorios.add(file);
                    conArrayList(file);
                } else {
                    throw new FileNotFoundException("Error, fichero no existe");
                }
            } catch (FileNotFoundException e) {
                e.getMessage();
            } catch (Exception e) {
                e.getMessage();
            }
        }
        Collections.sort(archivos);

        
        
    }
    public static TreeMap<String, ArrayList> IndiceDefinitivo= new TreeMap();
    private void escribe(){  
        
        
        for(int i=0; i<archivos.size();i++){
            ArrayList<String> rutasIn=new ArrayList<String>();
            String nombreinicial=archivos.get(i).getName();//nombre del archivo que estamos mirando
            String nombreAux="";//resto de nombres a mirar, lo usaremos dentro del otro for
            String ruta=archivos.get(i).getAbsolutePath();
            for(int k=i;k<archivos.size();k++){//este for es para mirar las veces que encontramos el archivo
                if(k!=i && i<archivos.size()){
                    nombreAux=archivos.get(k).getName();
                    if(nombreinicial.equals(nombreAux) && !IndiceDefinitivo.containsKey(nombreinicial)){
                        rutasIn.add(archivos.get(k).getAbsolutePath());
                    }else{
                        continue;
                    }
                }else{
                    nombreAux=archivos.get(k).getName();
                    if(!IndiceDefinitivo.containsKey(nombreAux)){
                        rutasIn.add(archivos.get(k).getAbsolutePath());
                    }
                }
                if(IndiceDefinitivo.containsKey(nombreinicial)){
                    continue;
                }
            }
            String acu=nombreinicial;//acumulador de nombre mas rutas del archivo
            for(int l=0;l<rutasIn.size();l++){
                acu+=";"+rutasIn.get(l);
                System.out.println(nombreinicial+"-->"+rutasIn.get(l));
            }
            if(!rutasIn.isEmpty()){//aqui tenemos la cadena de cada archivo con el nombre;ruta1;ruta2;...
                System.out.println(acu);
                resumenRutas.add(acu);
            }
            IndiceDefinitivo.put(nombreinicial,rutasIn);//mirar como se escribe un TreeMap en un fichero
        }
        
        //Comprobar la escritura, mirar api TreeMap
        
        //for (int i = 0; i < archivos.size(); i++) {
        for (int i = 0; i < resumenRutas.size(); i++) {
            try {//para escribir
                FileWriter fw = new FileWriter(indice, true);
                BufferedWriter BW = new BufferedWriter(fw);

                //BW.write(archivos.get(i).getAbsolutePath() + "\n");
                BW.write(resumenRutas.get(i)+"\n");
                BW.close();
                fw.close();//no olvidar de cerrar
            } catch (IOException or) {
            }
        }
    }

    public void muestra() {
        for (int i = 0; i < archivos.size(); i++) {
            System.out.println("->" + archivos.get(i));
        }
    }

    private class NumeroArgumentosException extends Exception {
        public NumeroArgumentosException(String msg) {
            super(msg);
        }
    }

}
