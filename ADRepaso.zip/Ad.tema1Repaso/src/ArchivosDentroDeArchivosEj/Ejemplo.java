/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.

 */
package ArchivosDentroDeArchivosEj;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author Christian
 */
public class Ejemplo {
//Ejemplo de acceso dentro de directorios recursivo (Eje:3,4,5)
    public static void verContenidoFolder(File dir) {
        try {
            File[] files
                    = dir.listFiles();
            for (File file : files) {
                if (file.isDirectory()) {
                    System.out.println("directorio:" + file.getCanonicalPath());
                    verContenidoFolder(file);
                } else {
                    System.out.println(" archivo:"
                            + file.getCanonicalPath());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
