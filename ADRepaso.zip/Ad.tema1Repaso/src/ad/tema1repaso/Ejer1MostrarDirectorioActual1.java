/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

import java.io.File;

/**
 *
 * @author Christian
 */
public class Ejer1MostrarDirectorioActual1 {

    
    public static void main(String[] args) {
       File f= new File(".");
        String [] listaFicheros=f.list(); //La lista nunca estar� vac�a (al menos contendr� "." y "..")
        System.out.println("Los ficheros del directorio actual son:");
        for (int i=0;i< listaFicheros.length;i++){
            System.out.println(listaFicheros[i]);
	}
    }
}
