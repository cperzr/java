/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

/**
 *
 * @author Christian
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class Ej15IndiceRAF {

    private static int ultimoIDutilizado = 0;

    /*VARIABLES STATICAS FINAL PARA EL BYTE DE CONTROL*/
    private static final byte BORRADO = 1;
    private static final byte DISPONIBLE = 0;

    private static boolean indicesCreados = false;
    //Tree para el id con el nombre de EMpleado
    private static TreeMap<Integer, String> indice1Map = new TreeMap<Integer, String>();

    //Tree con el id y la posicion para hacer el random Acces File.
    private static TreeMap<Integer, Long> indice2Map = new TreeMap<Integer, Long>();
    private static File index1 = new File("indice1");
    private static File index2 = new File("indice2");
    private static File datos = new File("Empleados.dat");

    public static void main(String args[]) throws IOException {

        index1.createNewFile();
        index2.createNewFile();
        datos.createNewFile();
        Ej15IndiceRAF ej15 = new Ej15IndiceRAF();
        if ((index1.exists()) && (index2.exists())) {
            ej15.rellenarIndices();
            indicesCreados = true;
        }
        boolean salir = false;
        Scanner sc = new Scanner(System.in);
        int opcion=0;
        do {
            System.out.println("INTRODUZCA EL NUMERO DE LO QUE QUIERE HACER");
            System.out.println("\n1) Crear índice");
            System.out.println("2) Alta a empleado");
            System.out.println("3) Baja a empleado");
            System.out.println("4) Modificar empleado");
            System.out.println("5) Consulta a empleado");
            System.out.println("6) Reconstruir fichero de Datos");
            System.out.println("7) SALIR.\n");

            try{
                opcion = sc.nextInt();
            }catch(InputMismatchException ie){
                System.out.println("Introduce un numero");
                sc.nextLine();//limpiar escaner 100% necesario
            }
            
            switch (opcion) {
                case 1:
                    //ej15.crearIndices();
                    ej15.rellenarIndices();
                    indicesCreados = true;

                    break;

                case 2:
                    if (indicesCreados) {
                        ej15.altaEmpleado();
                        ej15.actualizarIndices();
                    } else {
                        System.out.println("Debes crear los indices antes de usar este apartado.");
                    }

                    break;

                case 3:
                    if (indicesCreados) {
                        ej15.bajaEmpleado();
                        ej15.actualizarIndices();

                    } else {
                        System.out.println("Debes crear los indices antes de usar este apartado.");
                    }

                    break;

                case 4:
                    if (indicesCreados) {
                        ej15.modificarEmpleado();
                        ej15.actualizarIndices();

                    } else {
                        System.out.println("Debes crear los indices antes de usar este apartado.");
                    }

                    break;

                case 5:
                    if (indicesCreados) {
                        ej15.consultarEmpleado();

                    } else {
                        System.out.println("Debes crear los indices antes de usar este apartado.");
                    }

                    break;

                case 6:
                    if (indicesCreados) {
                        System.out.println("Reconstruyendo fichero");

                        ej15.reconstruirFichero();
                        /*Para crear el indice de nuevo segun el fichero reconstruido (las posiciones del seek)*/
                        ej15.rellenarIndices();
                        /*Para escribirlos en el fichero indice1 y 2.*/
                        ej15.actualizarIndices();
                        System.out.println("Fichero Reconstruido");

                    } else {
                        System.out.println("Debes crear los indices antes de usar este apartado.");
                    }

                    break;

                case 7:

                    salir = true;
                    break;

                default:
                    System.out.println("Introduzca un numero del 1 al 7");
                    break;
            }

        } while (!salir);

    }

    /*private void crearIndices() {

        try {

            if (index1.exists() && index2.exists()) {
                System.out.println("Los indices ya existen");
            } else {
                index1.createNewFile();
                index2.createNewFile();
                System.out.println("Indices creados correctamente.");

            }

        } catch (IOException e) {

        }

    }*/

    private void altaEmpleado() throws IOException {
        Scanner sc = new Scanner(System.in);

        RandomAccessFile salidaRAF = null;

        try {
            salidaRAF = new RandomAccessFile(datos, "rw");
            /*Posicionamos el puntero en el final del archivo*/
            long posicion = salidaRAF.length();//posicion donde emèzaremos a escribir por tanto donde tenemos que buscar
            salidaRAF.seek(posicion);

            int id = ultimoIDutilizado + 1;
            ultimoIDutilizado++;
            salidaRAF.writeInt(id);

            System.out.println("Introduce nombre completo del Empleado para dar de alta.");
            String nombreEmp = sc.nextLine();
            salidaRAF.writeUTF(nombreEmp);

            System.out.println("Introduce ciudad del Empleado");
            String ciudadEmp = sc.nextLine();
            salidaRAF.writeUTF(ciudadEmp);

            System.out.println("Introduce departamento del Empleado");
            String depEmp = sc.nextLine();
            salidaRAF.writeUTF(depEmp);

            byte control = DISPONIBLE;
            salidaRAF.writeByte(control);

            /*Guardamos los datos necesarios en los TREEMAPS de los indices.*/
            indice1Map.put(id, nombreEmp);//tiene el id y nombre
            indice2Map.put(id, posicion);// tiene el id y la posicion.

        } catch (FileNotFoundException e) {
            System.out.println("No se encuentra el archivo.");
        } finally {
            if (salidaRAF != null) {
                salidaRAF.close();
            }

        }

    }

    private void bajaEmpleado() throws IOException {

        Scanner sc = new Scanner(System.in);

        RandomAccessFile entradaSalidaRAF = null;

        try {
            entradaSalidaRAF = new RandomAccessFile(datos, "rw");

            System.out.println("Introduce ID del Empleado para dar de baja.");
            int id = sc.nextInt();

            sc.nextLine();//Reseteo scanner

            if (indice2Map.containsKey(id)) {
                /*Busco la posicion en mi indice*/
                long posicion = indice2Map.get(id);

                entradaSalidaRAF.seek(posicion);

                int idLeido = entradaSalidaRAF.readInt();

                String nombreEmp = entradaSalidaRAF.readUTF();

                String ciudadEmp = entradaSalidaRAF.readUTF();

                String depEmp = entradaSalidaRAF.readUTF();

                System.out.println("Empleado con id " + idLeido + "\nNombre: " + nombreEmp + " , ciudad: " + ciudadEmp + " , departamento: " + depEmp);
                System.out.println("¿Quiere borrar al Empleado seleccionado?(pulsa s para borrar)");
                String decision = sc.nextLine();

                if (decision.toLowerCase().equals("s")) {

                    entradaSalidaRAF.writeByte(BORRADO);

                    /*Borrando de los TREEMAPS*/
                    indice1Map.remove(idLeido);
                    indice2Map.remove(idLeido);

                    System.out.println("Empleado borrado satisfactoriamente.");
                } else {
                    System.out.println("El empleado no ha sido borrado");
                }

            } else {
                System.out.println("No existe Empleado con este ID");
            }

        } catch (FileNotFoundException e) {
            System.out.println("Error al leer el archivo.");
        } finally {
            if (entradaSalidaRAF != null) {
                entradaSalidaRAF.close();
            }

        }

    }

    private void modificarEmpleado() throws IOException {

        Scanner sc = new Scanner(System.in);

        RandomAccessFile entradaSalidaRAF = null;

        try {
            entradaSalidaRAF = new RandomAccessFile(datos, "rw");

            System.out.println("Introduce ID del Empleado para modificar.");
            int id = sc.nextInt();

            sc.nextLine();//Reseteo scanner

            if (indice2Map.containsKey(id)) {
                /*Busco la posicion en mi indice*/
                long posicion = indice2Map.get(id);

                entradaSalidaRAF.seek(posicion);

                int idLeido = entradaSalidaRAF.readInt();
                System.out.println("Introduce nuevo nombre completo");

                String nombreEmp = sc.nextLine();
                entradaSalidaRAF.writeUTF(nombreEmp);

                System.out.println("Introduce nueva ciudad");
                String ciudadEmp = sc.nextLine();
                entradaSalidaRAF.writeUTF(ciudadEmp);

                System.out.println("Introduce nuevo departamento");
                String depEmp = sc.nextLine();
                entradaSalidaRAF.writeUTF(depEmp);

                /*al cambiar el nombre y ser un valor de un indice, hay que cambiarlo*/
                indice1Map.put(idLeido, nombreEmp);
                //el segundo indice no se le toca porque la id seria la misma y la posicion tambien
            }

        } catch (FileNotFoundException e) {
            System.out.println("Error al leer el archivo.");
        } finally {
            if (entradaSalidaRAF != null) {
                entradaSalidaRAF.close();
            }

        }

    }

    private void consultarEmpleado() throws IOException {

        Scanner sc = new Scanner(System.in);

        RandomAccessFile entradaRAF = null;

        try {
            entradaRAF = new RandomAccessFile(datos, "r");

            System.out.println("Introduce ID del Empleado para consultar.");
            int id = sc.nextInt();

            sc.nextLine();//Reseteo scanner

            if (indice2Map.containsKey(id)) {
                /*Busco la posicion en mi indice*/
                long posicion = indice2Map.get(id);

                entradaRAF.seek(posicion);

                int idLeido = entradaRAF.readInt();

                String nombreEmp = entradaRAF.readUTF();

                String ciudadEmp = entradaRAF.readUTF();

                String depEmp = entradaRAF.readUTF();

                System.out.println("Empleado con id " + idLeido + "\nNombre: " + nombreEmp + " , ciudad: " + ciudadEmp + " , departamento: " + depEmp);

            } else {
                System.out.println("No existe Empleado con este ID");
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error al leer el archivo.");
        } finally {
            if (entradaRAF != null) {
                entradaRAF.close();
            }

        }

    }

    private void reconstruirFichero() throws IOException {

        RandomAccessFile entradaRAF = null;
        RandomAccessFile salidaRAF = null;

        File archivoTemporal = null;

        try {
            archivoTemporal = new File("archivoTemporal");
            archivoTemporal.createNewFile();

            entradaRAF = new RandomAccessFile(datos, "r");
            salidaRAF = new RandomAccessFile(archivoTemporal, "rw");

            while (entradaRAF.getFilePointer() < datos.length()) {
                //Cojo primero la posicion para que sea al inicio del Empleado, para poder hacer seek
                long posicion = entradaRAF.getFilePointer();

                int id = entradaRAF.readInt();
                String nombreCompleto = entradaRAF.readUTF();
                String ciudad = entradaRAF.readUTF();
                String departamento = entradaRAF.readUTF();
                byte control = entradaRAF.readByte();

                if (control == DISPONIBLE) {
                    salidaRAF.writeInt(id);
                    salidaRAF.writeUTF(nombreCompleto);
                    salidaRAF.writeUTF(ciudad);
                    salidaRAF.writeUTF(departamento);
                    salidaRAF.writeByte(control);

                }
            }
            File archivoOriginal = new File(datos.getAbsolutePath());

            datos.delete();

            archivoTemporal.renameTo(archivoOriginal);//rename to solo permite objetos File, no String

        } catch (FileNotFoundException e) {
            System.out.println("Error al leer el archivo.");
        } finally {
            if (entradaRAF != null) {
                entradaRAF.close();
            }
            if (salidaRAF != null) {
                salidaRAF.close();
            }
        }

    }

    private void actualizarIndices() throws IOException {
        RandomAccessFile fileOutRAF = null;
        /*Para escribir el indice de ID-NOMBRECOMPLETO*/
        try {
            fileOutRAF = new RandomAccessFile(index1, "rw");
            Set set = indice1Map.entrySet();//es para instanciar el iterator(de este indice vamos a iterar)
            Iterator it = set.iterator();

            while (it.hasNext()) {
                Map.Entry me = (Map.Entry) it.next();

                int key = (int) me.getKey();
                String value = (String) me.getValue();

                fileOutRAF.writeInt(key);
                fileOutRAF.writeUTF(value);
            }
        } catch (FileNotFoundException e) {
            System.out.println("No se encuentra alguno de los archivos indices.");
        } finally {
            if (fileOutRAF != null) {
                fileOutRAF.close();
            }

        }

        /*Para escribir el indice de ID-POSICION*/
        try {
            fileOutRAF = new RandomAccessFile(index2, "rw");
            Set set = indice2Map.entrySet();
            Iterator it = set.iterator();

            while (it.hasNext()) {
                Map.Entry me = (Map.Entry) it.next();

                int key = (int) me.getKey();
                long value = (long) me.getValue();

                fileOutRAF.writeInt(key);
                fileOutRAF.writeLong(value);
            }
        } catch (FileNotFoundException e) {
            System.out.println("No se encuentra alguno de los archivos indices.");
        } finally {
            if (fileOutRAF != null) {
                fileOutRAF.close();
            }

        }

    }

    private void rellenarIndices() throws IOException {

        RandomAccessFile flujoEntradaDatos = null;

        try {

            flujoEntradaDatos = new RandomAccessFile(datos, "r");
            int id;
            while (flujoEntradaDatos.getFilePointer() < datos.length()) {//aqui hago que el punto en el que empiezo sea menor que el length de los datos continue
                //Cojo primero la posicion para que sea al inicio del Empleado, para poder hacer seek, siempre LONG(porque solo permite long)
                long posicion = flujoEntradaDatos.getFilePointer();

                id = flujoEntradaDatos.readInt();
                String nombreCompleto = flujoEntradaDatos.readUTF();
                String ciudad = flujoEntradaDatos.readUTF();
                String departamento = flujoEntradaDatos.readUTF();
                byte control = flujoEntradaDatos.readByte();

                if (control == DISPONIBLE) {
                    indice1Map.put(id, nombreCompleto);//tiene el id y nombre
                    indice2Map.put(id, posicion);// tiene el id y la posicion.
                }
                // Para guardar el ultimo id utilizado
                if(ultimoIDutilizado<id){
                    ultimoIDutilizado = id;
                }
            }

        } catch (FileNotFoundException e) {
            System.out.println("No se encuentra el archivo");
        } catch (IOException e) {
            System.out.println("Error al leer el fichero");
        } finally {
            if (flujoEntradaDatos != null) {
                flujoEntradaDatos.close();
            }
        }

    }

}
