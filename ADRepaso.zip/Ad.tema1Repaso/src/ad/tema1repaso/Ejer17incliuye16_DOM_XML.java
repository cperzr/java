package ad.tema1repaso;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Christian
 */
import java.io.File;
import java.io.StringWriter;
import java.io.Writer;
import java.util.InputMismatchException;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class Ejer17incliuye16_DOM_XML {

    private static File fileXML;

    private static DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    private static DocumentBuilder builder;
    private static DOMImplementation implementation;
    private static Document document;

    public static void main(String args[]) throws Exception {

        Scanner sc = new Scanner(System.in);
        int opt = 0;
        boolean error = false;
        while (!error) {
            try {

                System.out.println("BIENVENIDO AL GESTOR DE EMPLEADOS, ELIJA UNA OPERACION\n");
                System.out.println("01-----CREAR FICHERO DE EMPLEADOS");
                System.out.println("02-----ABRIR FICHERO DE EMPLEADOS");
                System.out.println("03-----INTRODUCIR UN NUEVO EMPLEADO");
                System.out.println("04-----BORRAR UN EMPLEADO");
                System.out.println("05-----MODIFICAR UN EMPLEADO");
                System.out.println("06-----LEER XML");
                System.out.println("07-----SALIR");

                opt = sc.nextInt();

            } catch (InputMismatchException e) {
                sc.nextLine();//limpio la entrada del Scanner
                System.out.println("INTRODUZCA UN NUMERO POR FAVOR");
            }

            switch (opt) {
                case 1:
                    crear();
                    break;
                case 2:
                    abrir();
                    break;
                case 3:
                    nuevoEmpleado();
                    break;
                case 4:
                    borrarEmpleado();
                    break;
                case 5:
                    modificarEmpleado();
                    break;
                case 6:
                    leerEmpleado();
                    break;
                case 7:
                    finalizar();
                    System.exit(0);
                    break;
                default:
                    System.out.println("OPCION NO VALIDA");
                    break;

            }

        }
    }//main

    public static void crear() throws ParserConfigurationException {
        Scanner sc = new Scanner(System.in);
        //pido al usuario la ruta donde quiere crear el nuevo archivo xml
        System.out.println("introduce la ruta donde deseas crear el archivo xml");
        String ruta = sc.nextLine();
        //hago un substring de las ultimos tres caracteres para comprobar si es "xml"

        String extension = ruta.substring(ruta.length() - 3);

        fileXML = new File(ruta);

        //mientras no exista la ruta que hemos introducido o la extension no sea xml, seguira pidiendo al usuario una ruta valida
        while (fileXML.exists() || (!extension.equals("xml"))) {
            System.out.println("ha introducido una ruta o extension del archivo erronea, por favor repita la operacion");
            ruta = sc.nextLine();
            extension = ruta.substring(ruta.length() - 3);
            fileXML = new File(ruta);
        }
        System.out.println("nuevo archivo xml creado");

        //inicializo los objetos necesarios  para la creacion de un xml en memoria RAM
        builder = factory.newDocumentBuilder();
        implementation = builder.getDOMImplementation();
        document = implementation.createDocument(null, "empleados", null);//raiz que tendra interna el documento
        document.setXmlVersion("1.0");

    }

    public static void abrir() throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.println("introduce la ruta donde este el archivo XML");
        String ruta = sc.nextLine();
        //capturo los tres ultimos caracteres de la ruta introducida
        String extension = ruta.substring(ruta.length() - 3, ruta.length());

        fileXML = new File(ruta);

        while (!fileXML.exists() || !extension.equals("xml")) {
            System.out.println("ha introducido una ruta o extension del archivo erronea, por favor repita la operacion");
            ruta = sc.nextLine();
            extension = ruta.substring(ruta.length() - 3, ruta.length());
            fileXML = new File(ruta);
        }

        cargarEmpleados();

    }

    public static void modificarEmpleado() {
        Scanner sc = new Scanner(System.in);
        boolean seguirCambiando = false;
        String opt = "";
        String nombre = "";
        String apellido = "";
        float salario = 0;
        int id = 0;

        while (nombre.equals("") || apellido.equals("")) {
            System.out.println("INTRODUCE LOS SIGUIENTES DATOS DEL EMPLEADO A BORRAR, DEBE CUMPLIMENTAR AMBOS O SINO SE VOLVERAN A PEDIR LOS DATOS");
            System.out.println("INTRODUCE EL NOMBRE");
            nombre = sc.nextLine();
            System.out.println("INTRODUCE EL APELLIDO");
            apellido = sc.nextLine();
        }

        //crea una lista con todos los nodos empleado
        NodeList empleados = document.getElementsByTagName("empleado");
        //recorrer la lista
        boolean encontrado = false;
        int numero = 0;
        for (int i = 0; i < empleados.getLength(); i++) {

            Node emple = empleados.item(i);//obtener un nodo de empleado

            if (emple.getNodeType() == Node.ELEMENT_NODE) {//compruebo que mi nodo empleado es un elemento y no un text

                Element elemento = (Element) emple;//obtener los elementos del nodo empleado

                if (getNodo("nombre", elemento).equals(nombre) && getNodo("apellido", elemento).equals(apellido)) {
                    encontrado = true;
                    numero = i;
                    //cuando encuentro el empleado que quiero borrar almaceno sus datos en mis variables para despues cambiarlas
                    nombre = getNodo("nombre", elemento);
                    apellido = getNodo("apellido", elemento);
                    salario = Float.parseFloat(getNodo("salario", elemento));
                    id = Integer.parseInt(getNodo("id", elemento));
                }

            }
        }
        if (encontrado) {
            //una vez recogido los valores del empleado a borrar, puedo borrar su nodo del arbol
            //sirve para borrar nodos, en este caso el nodo empleado cuyo elemento nombre es el que hemos elegido
            Element empleadoBorrar = (Element) document.getElementsByTagName("empleado").item(numero);
            empleadoBorrar.getParentNode().removeChild(empleadoBorrar);

            while (!seguirCambiando) {
                System.out.println("INDIQUE QUE PARAMETRO QUIERE CAMBIAR");
                System.out.println("01----------NOMBRE");
                System.out.println("02----------APELLIDO");
                System.out.println("03----------SALARIO");
                System.out.println("04----------ID");
                System.out.println("05----------SALIR");
                opt = sc.nextLine();

                switch (opt) {
                    case "1":
                        System.out.println("INTRODUZCA EL NUEVO NOMBRE");
                        nombre = sc.nextLine();
                        break;
                    case "2":
                        System.out.println("INTRODUZCA EL NUEVO APELLIDO");
                        apellido = sc.next();
                        break;
                    case "3":
                        System.out.println("INTRODUZCA EL NUEVO SALARIO");
                        salario = sc.nextFloat();
                        sc.nextLine();
                        break;
                    case "4":
                        System.out.println("INTRODUZCA EL NUEVO ID");
                        id = sc.nextInt();
                        sc.nextLine();
                        break;
                    case "5":
                        seguirCambiando = true;
                        break;
                    default:
                        System.out.println("opcion no valida");
                        break;

                }

            }

            //ya con los datos modificados y el nodo origen borrado, creo otro nodo con todos los datos modificados del empleado y los añado a la raiz
            //en este caso no es necesario saber si el archivo xml existe o no, ya que si estamos modificando un archivo xml se da por supuesto que ya existe previamente
            //creo el elemento empleado donde añadire los datos obtenidos
            //creo un elemento que luego añadire a la raiz
            Element ElementoEmpleado = document.createElement("empleado");

            //añado empleado a la raiz principal del documento, empleados
            document.getDocumentElement().appendChild(ElementoEmpleado);

            //creo los hijos del elemento empleado
            Element nombreEmpleado = document.createElement("nombre");
            Element apellidoEmpleado = document.createElement("apellido");
            Element salarioEmpleado = document.createElement("salario");
            Element idEmpleado = document.createElement("id");

            //creo los objetos Text con el valor de los datos que he obtenido
            Text valorNombre = document.createTextNode(nombre);
            Text valorApellido = document.createTextNode(apellido);
            Text valorSalario = document.createTextNode("" + salario);
            Text valorId = document.createTextNode("" + id);

            //enlazo el valor de los elementos con sus elementos, nombreEmpleado con valorNombre, por ejemplo
            nombreEmpleado.appendChild(valorNombre);
            apellidoEmpleado.appendChild(valorApellido);
            salarioEmpleado.appendChild(valorSalario);
            idEmpleado.appendChild(valorId);

            //por ultimo añado el elemento nombre de empleado con su texto a mi elemento empleado
            ElementoEmpleado.appendChild(nombreEmpleado);
            ElementoEmpleado.appendChild(apellidoEmpleado);
            ElementoEmpleado.appendChild(salarioEmpleado);
            ElementoEmpleado.appendChild(idEmpleado);

        } else {
            System.out.println("el empleado que quiere cambiar no existe en el sistema");
        }

    }

    public static void borrarEmpleado() {
        //todo lo necesario para empezar a leer el archivo ya se hace en el momento que cargamos el arbol en memoria con cargarEmpleados()

        Scanner sc = new Scanner(System.in);
        System.out.println("INTRODUZCA EL NOMBRE DE LA PERSONA A BORRAR");
        String nombre = sc.nextLine();
        System.out.println("INTRODUZCA EL APELLIDO DE LA PERSONA A BORRAR");
        String apellido = sc.nextLine();

        //crea una lista con todos los nodos empleado
        NodeList empleados = document.getElementsByTagName("empleado");
        //recorrer la lista
        boolean encontrado = false;
        int numero = 0;
        for (int i = 0; i < empleados.getLength(); i++) {

            Node emple = empleados.item(i);//obtener un nodo de empleado

            if (emple.getNodeType() == Node.ELEMENT_NODE) {//compruebo que mi nodo empleado es un elemento y no un text

                Element elemento = (Element) emple;//obtener los elementos del nodo empleado

                if (getNodo("nombre", elemento).equals(nombre) && getNodo("apellido", elemento).equals(apellido)) {
                    encontrado = true;
                    numero = i;
                }

            }
        }
        if (encontrado) {
            //sirve para borrar nodos, en este caso el nodo empleado cuyo elemento nombre es el que hemos elegido
            Element empleadoBorrar = (Element) document.getElementsByTagName("empleado").item(numero);
            empleadoBorrar.getParentNode().removeChild(empleadoBorrar);

        }
    }

    public static String getNodo(String etiqueta, Element empleado) {
        //como sabemos que solo tendremos un valor de nombre por cada empleado, lo capturamos como .item(0)
        //el NodeList nos guardara todo los hijos de mi elemento nombre, en nuestro caso solo es uno 
        NodeList nodosDeLaEtiquetaDeEmpleado = empleado.getElementsByTagName(etiqueta).item(0).getChildNodes();
        //cogemos el primero valor de los nodos con la etiqueta que le hemos pasado, perteneciente a empleado, al solo haber un valor en mi lista no tiene mucho sentido esto
        Node valorNodoDeLaEtiqueta = (Node) nodosDeLaEtiquetaDeEmpleado.item(0);
        //devuelvo el valor de ese elemento
        return valorNodoDeLaEtiqueta.getNodeValue();
    }

    public static final void prettyPrint(Document xml) throws Exception {

        Transformer tf = TransformerFactory.newInstance().newTransformer();
        tf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        tf.setOutputProperty(OutputKeys.INDENT, "yes");
        Writer out = new StringWriter();
        tf.transform(new DOMSource(xml), new StreamResult(out));
        System.out.println(out.toString());

    }

    /**
     * metodo que crea el archivo xml donde se guardaran los empleados
     *
     * @throws ParserConfigurationException
     */

    public static void leerEmpleado() throws Exception {
        prettyPrint(document);

    }

    public static void cargarEmpleados() throws Exception {
        //al obligar al usuario a tener que leer el documento despues de crearlo/abrirlo me permite tener siempre un arbol cargado en memoria RAM
        try {
            builder = factory.newDocumentBuilder();
            //si el File que le paso no existe me saltara la excepcion
            document = builder.parse(fileXML);
            document.getDocumentElement().normalize();
            //si todo esta correcto muestro mensaje a usuario
            System.out.println("archivo cargado correctamente");
        } catch (Exception e) {
            System.out.println("el archivo xml esta vacio o no existe");
        }
    }

    public static void nuevoEmpleado() throws ParserConfigurationException, TransformerException {
        Scanner sc = new Scanner(System.in);
        //inicializo los valores de empleado que quiero recoger
        String nombre = "", apellido = "";
        float salario = 0;
        int id = 0;
        //con este bucle me aseguro que los datos que salgan de el seran los correctos
        while (true) {
            try {
                //pido los datos al usuario y si se equivoca en el valor de alguno saltara la excepcion y volvera al principio del bucle
                System.out.println("INTRODUZCA LOS SIGUIENTES DATOS DEL NUEVO EMPLEADO");
                System.out.println("NOMBRE");
                nombre = sc.nextLine();
                System.out.println("APELLIDO");
                apellido = sc.nextLine();
                System.out.println("SALARIO");
                salario = sc.nextFloat();
                System.out.println("ID");
                id = sc.nextInt();
                sc.nextLine();
                //si todos los datos se han introducido correctamente salgo del bucle
                break;
            } catch (InputMismatchException ime) {
                System.out.println("ha introducido valores incorrectos");
                sc.nextLine();
            }
        }
        //una vez tengo los datos procedo a unirlos al arbol xml

        //creo un elemento empleado que luego añadire a la raiz
        Element ElementoEmpleado = document.createElement("empleado");

        //añado empleado a la raiz principal del documento, empleados
        document.getDocumentElement().appendChild(ElementoEmpleado);

        //creo los hijos del elemento empleado
        Element nombreEmpleado = document.createElement("nombre");
        Element apellidoEmpleado = document.createElement("apellido");
        Element salarioEmpleado = document.createElement("salario");
        Element idEmpleado = document.createElement("id");

        //creo los objetos Text con el valor de los datos que he obtenido
        Text valorNombre = document.createTextNode(nombre);
        Text valorApellido = document.createTextNode(apellido);
        Text valorSalario = document.createTextNode("" + salario);
        Text valorId = document.createTextNode("" + id);

        //enlazo el valor de los elementos con sus elementos, nombreEmpleado con valorNombre, por ejemplo
        nombreEmpleado.appendChild(valorNombre);
        apellidoEmpleado.appendChild(valorApellido);
        salarioEmpleado.appendChild(valorSalario);
        idEmpleado.appendChild(valorId);

        //por ultimo añado el elemento nombre de empleado con su texto a mi elemento empleado
        ElementoEmpleado.appendChild(nombreEmpleado);
        ElementoEmpleado.appendChild(apellidoEmpleado);
        ElementoEmpleado.appendChild(salarioEmpleado);
        ElementoEmpleado.appendChild(idEmpleado);

    }

    public static void finalizar() throws TransformerException {
        try {
            Source source = new DOMSource(document);
            //le digo en que fichero debe crear el xml
            Result result = new StreamResult(fileXML);

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            //le digo que me haga la transformacion desde source a mi fichero xml
            transformer.transform(source, result);
        } catch (TransformerConfigurationException tce) {
            System.err.println(tce.getMessage());
        } catch (TransformerException te) {
            System.err.println(te.getMessage());
        }
    }

}//class
