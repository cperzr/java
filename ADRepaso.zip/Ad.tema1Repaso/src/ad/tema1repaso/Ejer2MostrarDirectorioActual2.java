/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

import java.io.File;

/**
 *
 * @author Christian
 */
public class Ejer2MostrarDirectorioActual2 {
    private static void mostrarAyuda(){
        System.out.println("En la ruta especificada no hay directorio");
    }
    public static void main(String[] args) {
        System.out.println("mostrar directorios");
        if(args[0].equals("-h")){
            mostrarAyuda();
            return;
        }
        
        File f= new File(args[0]);
        if(f.exists()){
            if(f.isFile()){System.out.println(f.getName());}            
        }else if(f.isDirectory()){
            String listado[]=f.list();//si es un  directorio listamos lo que contiene
            for(int i=0; i<listado.length; i++){
                System.out.println(listado[i]);
            } 
        }
    }
}
