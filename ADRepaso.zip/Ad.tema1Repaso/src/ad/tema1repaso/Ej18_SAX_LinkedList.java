/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

/**
 *
 * @author Christian
 */
import com.thoughtworks.xstream.XStream;
import java.io.File;
import java.io.FileOutputStream;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class Ej18_SAX_LinkedList {

    private String currentElement;

    public static String mid;
    public String mapellido;
    public String msalario;
    public String mdep;

    private static int ultimoId = 0;

    //Variables de instancia de la clase SerializaraXML
    //IMPORTANTE TENER BIEN ESTA COLECCION
    private static class ColeccionEmpleados {

        private List<Empleado> listaEmpleados;

        public ColeccionEmpleados() {
            listaEmpleados = new LinkedList<Empleado>();
        }

        public void add(Empleado empleado) {
            listaEmpleados.add(empleado);
        }

        public void remove(int idenviado) {
            listaEmpleados.remove(idenviado);
        }

        public Empleado get(int idenviado) {
            return listaEmpleados.get(idenviado);

        }

        public void mostrarTODOS() {
            for (Empleado e : listaEmpleados) {
                e.mostrarEmpleado();
            }

        }

        private void comprobarUltimoID() {
            int idCapturado = 0;
            if (listaEmpleados.size() > 0) {
                for (Empleado e : listaEmpleados) {
                    idCapturado = Integer.parseInt(e.getmId());

                    if (idCapturado > ultimoId) {
                        ultimoId = idCapturado;
                    }

                }

            }
        }
    }

    static ColeccionEmpleados empleados = new ColeccionEmpleados();

    /*Constructor donde se hace la llamada al empezar el programa (lo primnero que hace el prog)*/
    public Ej18_SAX_LinkedList() {
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            //colocamos la direccion donde se encontrara el archivo
            saxParser.parse(new File("./xml/EmpleadosXStreamPropio.xml"), new MyHandler());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        /*cargamos el  XML en la linked list.*/
        new Ej18_SAX_LinkedList();

        /*capturamos el ultimo id*/
        empleados.comprobarUltimoID();

        /*Teniendo la linked list cargada, ahora permitimos altas bajas etc..*/
        boolean salir = false;
        int opt;
        do {
            mostrarMenu();
            opt = sc.nextInt();
            switch (opt) {
                case 1:
                    introducirEmpleado();

                    break;
                case 2:
                    borrarEmpleado();
                    break;
                case 3:
                    modificarEmpleado();
                    break;
                case 4:
                    empleados.mostrarTODOS();
                    break;
                case 5:

                    crearXML();

                    salir = true;
                    break;
                default:
                    System.out.println("Introduzca un valor entre 1 y 5");
                    break;
            }

        } while (salir == false);
        /*Aqui habria que escribir el xml y ya dejar que el programa saliese.*/

    }

    private static void crearXML() {
        XStream xstream = new XStream();

        xstream.alias("empleado", Empleado.class);
        xstream.alias("empleados", ColeccionEmpleados.class);

        //para que ID sea atributo de "empleado"
        xstream.useAttributeFor(Empleado.class, "id");

        // itera la lista.. pero no creas un tag para la listapersonas.
        xstream.addImplicitCollection(ColeccionEmpleados.class, "listaEmpleados");

        try {
            FileOutputStream ficheroXML = new FileOutputStream("./xml/EmpleadosXStreamPropio.xml");
            xstream.toXML(empleados, ficheroXML);

            System.out.println("Serializando la coleccion de empleados a fichero XML");

        } catch (Exception e) {
            System.out.println(e.toString());
        }

    }

    private static void introducirEmpleado() {
        Scanner sc = new Scanner(System.in);
        ultimoId++;
        String esteid = "" + ultimoId;
        System.out.println("Introduciendo nuevo empleado...\n");
        System.out.println("Introduzca apellido");
        String esteapellido = sc.nextLine();

        System.out.println("Introduzca departamento");
        String estedep = sc.nextLine();

        System.out.println("Introduzca salario");
        String estesalario = sc.nextLine();
        empleados.add(new Empleado(esteid, esteapellido, estedep, estesalario));

    }

    private static void borrarEmpleado() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca el id del empleado a borrar");
        int idamirar = sc.nextInt();

        int cont = 0;

        if (idamirar > ultimoId) {
            System.out.println("Ese id no existe");
        } else {
            if (idamirar > 0) {
                empleados.remove(idamirar - 1);
                cont++;

            }

            if (cont == 0) {
                System.out.println("Ese id no existe");
            }

        }

    }

    private static void modificarEmpleado() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca el id del empleado a modificar");
        int idamirar = sc.nextInt();

        /*Limpiamos scanner*/
        sc.nextLine();

        int cont = 0;

        if (idamirar > ultimoId) {
            System.out.println("Ese id no existe");
        } else {
            Empleado emp = empleados.get(idamirar - 1);

            if (emp != null) {
                System.out.println("Introduzca apellido(si pulsa intro sin introducir nada no se cambia)");
                String esteapellido = sc.nextLine();
                if (!esteapellido.equals("")) {
                    emp.setmApellido(esteapellido);
                }

                System.out.println("Introduzca departamento(si pulsa intro sin introducir nada no se cambia)");
                String estedep = sc.nextLine();
                if (!estedep.equals("")) {
                    emp.setmDep(estedep);
                }

                System.out.println("Introduzca salario(si pulsa intro sin introducir nada no se cambia)");
                String estesalario = sc.nextLine();
                if (!estesalario.equals("")) {
                    emp.setmSalario(estesalario);
                }

                cont++;
            }

            if (cont == 0) {
                System.out.println("Ese id no existe");
            }

        }

    }

    public static void mostrarMenu() {
        System.out.println("-------------MENU-------------------");
        System.out.println("INTRODUZCA LO QUE QUIERE HACER");
        System.out.println("01-----INTRODUCIR UN NUEVO EMPLEADO");
        System.out.println("02-----BORRAR UN EMPLEADO");
        System.out.println("03-----MODIFICAR UN EMPLEADO");
        System.out.println("04-----MOSTRAR TODOS LOS EMPLEADOS");
        System.out.println("05-----SALIR");

    }

    /* handler y clase Empleado */
    class MyHandler extends DefaultHandler {
        // Callback to handle element start tag

        @Override
        public void startElement(String uri, String localName, String qName,
                Attributes attributes) throws SAXException {
            currentElement = qName;

            if (currentElement.equals("empleado")) {

                mid = attributes.getValue("id");

            }
        }

        // Callback to handle element end tag
        @Override
        public void endElement(String uri, String localName, String qName)
                throws SAXException {
            //En caso de que la etiqueta sea la ultima etiqueta 
            //del nodo el cual queremos almacenar toda la informacion
            // almacenamos en la linkned todos los datos 
            if (currentElement.equals("salario")) {
                empleados.add(new Empleado(mid, mapellido, mdep, msalario));
            }
            currentElement = "";

        }

        // Callback to handle the character text data inside an element
        @Override

        public void characters(char[] chars, int start, int length) throws SAXException {

            if (currentElement.equals("apellido")) {

                mapellido = new String(chars, start, length);
            } else if (currentElement.equals("dep")) {

                mdep = new String(chars, start, length);
            } else if (currentElement.equals("salario")) {

                msalario = new String(chars, start, length);
            }

        }
    }

    static class Empleado {

        private String id;
        private String apellido;
        private String salario;
        private String dep;

        public Empleado(String mId, String mApellido, String mDep, String mSalario) {
            this.id = mId;
            this.apellido = mApellido;
            this.salario = mSalario;
            this.dep = mDep;
        }

        public String getmApellido() {
            return apellido;
        }

        public String getmDep() {
            return dep;
        }

        public String getmId() {
            return id;
        }

        public String getmSalario() {
            return salario;
        }

        public void setmApellido(String mApellido) {
            this.apellido = mApellido;
        }

        public void setmDep(String mDep) {
            this.dep = mDep;
        }

        public void setmId(String mId) {
            this.id = mId;
        }

        public void setmSalario(String mSalario) {
            this.salario = mSalario;
        }

        public void mostrarEmpleado() {
            System.out.println("Empleado con id: " + id + "\nApellido: " + apellido + "\nDepartamento: " + dep + "\nSalario: " + salario);
            System.out.println();

        }

    }
}
