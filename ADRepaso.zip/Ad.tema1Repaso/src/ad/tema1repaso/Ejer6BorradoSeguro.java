/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Christian
 */
public class Ejer6BorradoSeguro {
    static Scanner sc=new Scanner(System.in);
    public static void main(String[]args){
        
        File directorio=new File(System.getProperty("user.home"),"Desktop");
        File carpeta=new File(directorio,"borradoSeguro");
        if(!carpeta.exists()){//creamos la carpeta si no existe
            carpeta.mkdirs();//creamos la ruta de la carpeta
        }
        
        System.out.println("Introduce ruta del archivo a borrar");
        String RutaABorrar=sc.nextLine();
        File documento=new File(RutaABorrar);
        if(documento.isFile()){
            int cont=1;
            String nombre=documento.getName();
            int pos=nombre.lastIndexOf(".");
            String nombreSimple= nombre.substring(0, pos);
            String extencion=nombre.substring(pos);
            boolean existe=true;
            String annadido="";
            do{
                File Docexiste=new File(carpeta,nombreSimple+annadido+extencion);
                if(Docexiste.exists()){
                    annadido=""+cont;
                    cont++;
                }else{
                    documento.renameTo(Docexiste);
                    existe=false;
                    System.out.println("Borrado correcto");
                    //System.exit(0);
                }
            }while(existe!=false);
        System.out.println("Fin");
            
        }
    }
}
