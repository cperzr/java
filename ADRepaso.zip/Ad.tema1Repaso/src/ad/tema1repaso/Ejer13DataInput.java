/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

import static ad.tema1repaso.Ejer11.f;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.TreeSet;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author Christian
 */
/*
    FileOutputStream fileOut= new FileOutputStream(f,true);
    FileInputStream fileIn= new FileInputStream(f);
    DataOutputStream escribir= new DataOutputStream(fileOut);
    DataInputStream leer= new DataInputStream(fileIn);
    BufferedInputStream br = new BufferedInputStream(fileIn);
 */
public class Ejer13DataInput {

    static File f;
    static FileOutputStream fileOut;
    static FileInputStream fileIn;
    static DataOutputStream escribir;
    static DataInputStream leer;
    static String nombre = "";
    static String apellido = "";
    static float salario = 0;
    static int id = 0;
    static File temp;
    static String barra;

    public static void main(String[] args) throws IOException {

        File home = FileSystemView.getFileSystemView().getHomeDirectory();//directorio del escritorio
        String dir = home.getAbsolutePath();//ruta del escritorio
        barra = System.getProperty("file.separator");//separador del sistema operativo
        String comprueba = dir + barra + "13";//nombre del archivo en el ecrtorio del sistema operativo

        f = new File(comprueba);

        do {
            Scanner sc1 = new Scanner(System.in);
            System.out.println("Introduce opcion:\n1)Alta de empleado\n2)Baja\n3)modificacion\n4)consulta\n5)Fin de programa\n6)Crear nuevo documento\n7)Abrir documento");
            int opcion = sc1.nextInt();
            switch (opcion) {
                case 1:
                    Alta(f);
                    break;
                case 2:
                    Baja(f);
                    break;
                case 3:
                    Modificado(f);
                    break;
                case 4:
                    Consulta(f);
                    break;
                case 5:
                    Fin();
                    break;
                case 6:
                    crear();
                    break;
                case 7:
                    abrir();
                    break;
                default:
                    System.out.println("Opcion no conemplada");
                    break;
            }
        } while (true);

    }

    public static void crear() throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("INTRODUZCA LA RUTA DONDE QUIERE CREAR EL ARCHIVO");
        String linea = sc.nextLine();
        //inicio mi objeto file de tipo File
        f = new File(linea);
        //captura la excepcion por si no existe la ruta
        try {
            f.createNewFile();
            //si intento crear el archivo en una ruta que no existe saltara la excepcion
        } catch (IOException e) {
            System.out.println("----RUTA INCORRECTA-----");
        }
    }

    /**
     * Metodo que abre ya un archivo existente con los datos de los empleados
     */
    public static void abrir() {
        Scanner sc = new Scanner(System.in);
        System.out.println("ESCRIBA LA RUTA DONDE SE ENCUENTRA EL ARCHIVO");
        //comprobar si existe el archivo
        String linea = sc.nextLine();
        //inicio mi objeto file de tipo File con la ruta que ha introducido el usuario
        f = new File(linea);
        //compruebo que la ruta que me ha pasado el usuario contiene un archivo valido
        if (!f.isFile()) {
            System.out.println("EL ARCHIVO NO EXISTE");
        }
    }

    private static void Alta(File f) throws IOException {
        Scanner sc = new Scanner(System.in);

        fileOut = new FileOutputStream(f, true);
        escribir = new DataOutputStream(fileOut);
        try {
            System.out.println("POR FAVOR INTRODUZCA LA SIGUIENTE SECUENCIA DE DATOS\n");
            System.out.print("NOMBRE:");
            nombre = sc.nextLine();
            System.out.print("APELLIDO:");
            apellido = sc.nextLine();
            System.out.print("SALARIO:");
            salario = sc.nextFloat();
            System.out.print("CODIGO:");
            id = sc.nextInt();
            sc.nextLine();

            //si introduzco un dato no valido....
        } catch (InputMismatchException e) {
            System.out.println("DATO ERRONEO");
        }
        // doy valor a mi objeto fileIn del tipo FileInputStream para poder recorrer los datos de los empleados ya existentes en el archivo
        // esto lo hago para ver si el empleado que quiero meter ya existe en mi archivo empleados
        fileIn = new FileInputStream(f);
        //creo mi objeto de BufferedInputStream necesario para leer
        BufferedInputStream br = new BufferedInputStream(fileIn);
        //le tenemos que pasar al DataInputStream el objeto de de BufferedInputStream
        leer = new DataInputStream(br);
        //variables donde almaceno la lectura de empleados
        String nombree = "";
        String apellidoo = "";
        float salarioo = 0;
        int idd = 0;

        //booleano que controla si el empleado ya existe
        boolean yaExiste = false;

        //mientras haya bytes disponibles, mayores que 0, lee el patron
        while (br.available() > 0) {//el patron de lectura debe ser el mismo que el de escritura en mi archivo empleados
            nombree = leer.readUTF();
            apellidoo = leer.readUTF();
            salarioo = leer.readFloat();
            idd = leer.readInt();
            //si el nombre y apellido de alguno de los empleados que tengo en mi archivo empleados coincide con
            //el nombre y apellido del empleado que deseo introducir...
            if (nombre.equals(nombree) && (apellido.equals(apellidoo))) {
                //muestra mensaje de error
                System.out.println("ESTE REGRISTRO YA ESTA EN EL SISTEMA, ERROR");
                //el booleano que controla que ya exista ese empleado se pone a true
                yaExiste = true;
            } else if (id == idd) {
                System.out.println("Id ya esta introducido");
                //el booleano que controla que ya exista ese empleado se pone a true
                yaExiste = true;
            }

        }
        //si el empleado no estaba en nuestro archivo empleados...
        if (!yaExiste) {
            //se escriben todos los parametros de ese empleado en nuestro archivo empleados
            //respetando siempre el mismo patron
            escribir.writeUTF(nombre);
            escribir.writeUTF(apellido);
            escribir.writeFloat(salario);
            escribir.writeInt(id);
            //cuando acabo de escribir cierro mi objeto de escritura
            escribir.close();
        }

    }

    private static void Baja(File f) throws IOException {
        Scanner sc = new Scanner(System.in);
        Consulta(f);
        //se le pide al usuario el id del empleado a borrar 
        System.out.println("Introduce el id del usuario que deseas borrar");
        int idBorrado = sc.nextInt();
        //inicializo mi objeto fileTemp que contedra la ruta de mi archivo temporal que es el escritorio
        temp = new File(((FileSystemView.getFileSystemView().getHomeDirectory().getAbsolutePath()) + barra + "tem.txt"));
        //inicializo mi objeto fileOut de tipo  FileOutputStream necesario para poder escribir en mi archivo temporal
        fileOut = new FileOutputStream(temp);
        //inicializo mi objeto escribir de tipo DataOutputStream
        escribir = new DataOutputStream(fileOut);

        //inicializo mi objeto fileIn para poder leer en mi archivo de empleados
        fileIn = new FileInputStream(f);
        //para leer un archivo en bytes necesito la clase BufferedInputStream
        BufferedInputStream br = new BufferedInputStream(fileIn);
        //le tenemos que pasar al DataInputStream el objeto de de BufferedInputStream
        leer = new DataInputStream(br);

        //leo el contenido de mi archivo empleados
        while (br.available() > 0) {
            //tengo que leer con el mismo patron con el que escribo
            nombre = leer.readUTF();
            apellido = leer.readUTF();
            salario = leer.readFloat();
            id = leer.readInt();
            //voy escribiendo en mi archivo temporal todos aquellos empleados que no son el que yo quiero borrar

            if (id != idBorrado) {
                //escribo siempre con el mismo patron
                escribir.writeUTF(nombre);
                escribir.writeUTF(apellido);
                escribir.writeFloat(salario);
                escribir.writeInt(id);
            }

        }
        //cierro el objeto que me prmite escribir en mi archivo temporal
        escribir.close();
        //cierro el objeto que me permite leer mi archivo empleados
        leer.close();

        //ruta de mi archivo temporal
        String ruta = temp.getPath();
        System.out.println(ruta);
        Path origen = FileSystems.getDefault().getPath(ruta);
        //ruta de mi archivo empleados
        String ruta2 = f.getPath();
        System.out.println(ruta2);
        Path destino = FileSystems.getDefault().getPath(ruta2);
        //muevo mi archivo temporal a donde estaba el de empleados remplazandolo
        //de esta manera tengo un archivo empleados con el contenido de mi archivo temporal, es decir sin el empleado a borrar
        Files.move(origen, destino, StandardCopyOption.REPLACE_EXISTING);

    }

    private static void Modificado(File f) throws IOException {
        Scanner sc = new Scanner(System.in);
        Consulta(f);
        //se le pide al usuario el id del empleado a borrar 
        System.out.println("Introduce el id del usuario que deseas Modificar");
        int idModi = sc.nextInt();
        //inicializo mi objeto fileTemp que contedra la ruta de mi archivo temporal que es el escritorio
        temp = new File(((FileSystemView.getFileSystemView().getHomeDirectory().getAbsolutePath()) + barra + "tem.txt"));
        //inicializo mi objeto fileOut de tipo  FileOutputStream necesario para poder escribir en mi archivo temporal
        fileOut = new FileOutputStream(temp);
        //inicializo mi objeto escribir de tipo DataOutputStream
        escribir = new DataOutputStream(fileOut);

        //inicializo mi objeto fileIn para poder leer en mi archivo de empleados
        fileIn = new FileInputStream(f);
        //para leer un archivo en bytes necesito la clase BufferedInputStream
        BufferedInputStream br = new BufferedInputStream(fileIn);
        //le tenemos que pasar al DataInputStream el objeto de de BufferedInputStream
        leer = new DataInputStream(br);

        //leo el contenido de mi archivo empleados
        while (br.available() > 0) {
            //tengo que leer con el mismo patron con el que escribo
            nombre = leer.readUTF();
            apellido = leer.readUTF();
            salario = leer.readFloat();
            id = leer.readInt();
            //voy escribiendo en mi archivo temporal todos aquellos empleados que no son el que yo quiero borrar

            if (id == idModi) {
                sc.nextLine();
                //escribo siempre con el mismo patron
                System.out.print("NOMBRE:");
                String nombreb = sc.nextLine();
                nombre=nombreb;
                System.out.print("APELLIDO:");
                String apellidob = sc.nextLine();
                apellido=apellidob;
                System.out.print("SALARIO:");
                Float salariob = sc.nextFloat();
                salario=salariob;
                id=id;
            }
                escribir.writeUTF(nombre);
                escribir.writeUTF(apellido);
                escribir.writeFloat(salario);
                escribir.writeInt(id);

        }
        //cierro el objeto que me prmite escribir en mi archivo temporal
        escribir.close();
        //cierro el objeto que me permite leer mi archivo empleados
        leer.close();

        //ruta de mi archivo temporal
        String ruta = temp.getPath();
        System.out.println(ruta);
        Path origen = FileSystems.getDefault().getPath(ruta);
        //ruta de mi archivo empleados
        String ruta2 = f.getPath();
        System.out.println(ruta2);
        Path destino = FileSystems.getDefault().getPath(ruta2);
        //muevo mi archivo temporal a donde estaba el de empleados remplazandolo
        //de esta manera tengo un archivo empleados con el contenido de mi archivo temporal, es decir sin el empleado a borrar
        Files.move(origen, destino, StandardCopyOption.REPLACE_EXISTING);

    }

    private static void Consulta(File f) throws IOException {
        Scanner sc = new Scanner(System.in);
        //inicializo el objeto fileIn de tipo FileInputStream para poder leer 
        fileIn = new FileInputStream(f);
        // creo un objeto de BufferedInputStream para poder leer el archivo
        BufferedInputStream br = new BufferedInputStream(fileIn);
        //le tenemos que pasar al DataInputStream el objeto de de BufferedInputStream
        leer = new DataInputStream(br);

        //mientras haya bytes disponibles, mayores que 0, lee el patron
        while (br.available() > 0) {
            //leo con el mismo patron en el que escribi los datos
            nombre = leer.readUTF();
            apellido = leer.readUTF();
            salario = leer.readFloat();
            id = leer.readInt();
            //por cada vuelta del while muestro los datos de ese empleado
            System.out.println("LOS DATOS INTRODUCIDOS SON:\tNOMBRE: " + nombre + "\tAPELLIDO: " + apellido + "\tSALARIO: " + salario + "\tID: " + id);
        }
        //cierro mi objeto DataInputStream necesario para leer
        leer.close();
    }

    private static void Fin() {
        System.out.println("Fin de programa");
        System.exit(0);
    }
}
