/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Christian
 */
public class Ejer4Muestra {
    public static void main(String[] args) {
	ArrayList obj = new ArrayList();
        System.out.println("introduce direccion");
        Scanner sc=new Scanner(System.in);
        String direccion=sc.nextLine();
        File f= new File(direccion);
        if(f.exists()){
            String [] listaFicheros=f.list();
            Arrays.sort(listaFicheros);
            for(int i=0; i<listaFicheros.length;i++){
                obj.add(listaFicheros[i]);
            }

            for(int j=0; j<listaFicheros.length;j++){
                System.out.println(obj.get(j));
            }
        }else{
            System.out.println("Fichero no existente");
        }
        
        
    }
}
