/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Christian
 */
public class Ejer5LeePatron {
    public static void main(String[] args) throws IOException {
	ArrayList obj = new ArrayList();
        ArrayList<File> sol= new ArrayList();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); //Ya tenemos el "lector"
        
        System.out.println("Itroduce patron compuesto de . ? *");
        String patron= br.readLine(); 
        String patronb="";
        for(int cv=0;cv<patron.length();cv++){
            char caracter=patron.charAt(cv);
            if(Character.isLetter(caracter)  || Character.isDigit(caracter)){
                patronb+=caracter;
            }else if(caracter=='*'){
                patronb+="\\w";
            }else if(caracter=='.'){
                patronb+="\\.";
            }else if(caracter=='?'){
                patronb+="\\d";
            }
        }
        System.out.println("Itroduce donde se encuentra el fichero");
        String direccion= br.readLine();
        File f= new File(direccion);
        
        if(f.exists()){//obtengo los ficheros que hay en el directorio
            File [] listaFicheros=f.listFiles();
            for(int i=0; i<listaFicheros.length;i++){
                obj.add(listaFicheros[i]);
            }
            
            
            for(int j=0;j<listaFicheros.length;j++){
                boolean comprueba=compara(patron,listaFicheros[j]);
                if(comprueba){
                    
                    sol.add(listaFicheros[j]);
                }
            }
            int canttotal=sol.size();
            String atributo[][]=new String[canttotal][4];
            for(int k1=0;k1<atributo.length;k1++){
                
                if(sol.get(k1).isDirectory()){
                    atributo[k1][0]="d";                        
                }else{
                    atributo[k1][0]="-";  
                }
                 
                if(sol.get(k1).canRead()){
                    atributo[k1][1]="r";                        
                }else{
                    atributo[k1][1]="-";  
                }
                 
                if(sol.get(k1).canWrite()){
                    atributo[k1][2]="-";                        
                }else{
                    atributo[k1][2]="w";  
                }
                   
                    atributo[k1][3]="d"; 
            }
            for(int kF=0; kF<sol.size();kF++){
                for(int k2=0;k2<atributo.length;k2++){
                    for(int k3=0;k3<4;k3++){
                        System.out.print(atributo[k2][k3]+"");
                    }
                }
                String Fin= sol.get(kF).length()+"";
                System.out.print("\t"+Fin+"\t"+Fin);
            }
            
                
                    
            
        }else{//por si el fichero no existe
            System.out.println("Fichero no existente");
        }
        
    }
    private static boolean compara(String patron, File un){
        boolean bien=false;
        
        Pattern patr=Pattern.compile(patron);
        Matcher busca = patr.matcher(un.getName());
        if(busca.find()){
            bien=true;
        }
             
        return bien;
    }
}
