/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 *
 * @author Christian
 */
public class Ejer7 {
    public static void main(String[]args)throws IOException {
        FileInputStream in = null;
        FileOutputStream out = null;
        
        System.out.println("Introduzca la ruta de origen y de destino y si no quiere sobreescribir ponga delante -a");
        try{
            if(args.length==2){
                if(args[0].equals("-a")){
                    throw new FileNotFoundException("Tiene que introducir 2 argumentos que son rutas o 3 con el -a para no sobreescribir");
                }else{
                    File in1 = new File(args[0]);
                    File out1 = new File(args[1]);
                    if (!in1.exists()) {
                        throw new FileNotFoundException("no existe la ruta de inicio");
                    }
                    if (!out1.exists()) {//Si no existe lo creo con el metodo createNewFile()
                        out1.createNewFile();
                    }
                    
                    in= new FileInputStream(args[0]);
                    out=new FileOutputStream(args[1]);
                }
            }else if(args.length==3){
                if(args[0].equals("-a")){
                    File in1 = new File(args[1]);
                    File out1 = new File(args[2]);
                    
                    if (!in1.exists()) {
                        throw new FileNotFoundException("no existe la ruta de inicio");
                    }
                    if (!out1.exists()) {//Si no existe lo creo con el metodo createNewFile()
                        out1.createNewFile();
                    }
                    
                    in= new FileInputStream(args[1]);
                    out=new FileOutputStream(args[2], true);
                }
            }else{
                throw new FileNotFoundException("Numero de argumnetos incorrectos");
            }
            
            
            int c;

            while ((c = in.read()) != -1) {//escribo en destino
                out.write(c);
            }
        } finally {//cierro los File...Stream
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }
    }
}