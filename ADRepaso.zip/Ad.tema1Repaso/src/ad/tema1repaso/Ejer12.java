/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

import com.sun.xml.internal.ws.util.StringUtils;
import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ejer12 {

    public static void main(String args[]) throws IOException {

        File archivo = null;//archivo a leer
        
        FileReader lector = null;//objeto lectura
        FileWriter escritor = null;//objeto escritura

        BufferedReader inputStream = null;//bufer lectura
        BufferedWriter outputStream = null;//bufer escriturra

        String nombre;//nombre del archivo a formatear;
        String linea;
        try {
            switch (args.length) {
                case 1: //EN CASO DE QUE SOLO EXISTA UN ARGUMENTO (UNA RUTA DE FICHERO)

                    archivo = new File(args[0]);
                    lector = new FileReader(archivo);
                    inputStream = new BufferedReader(lector);

                    nombre = archivo.getName();

                    if (nombre.contains(".")) {
                        String cadena1 = nombre.substring(0, nombre.indexOf("."));
                        String cadena2 = nombre.substring(nombre.indexOf("."));
                        nombre = cadena1 + "-formateado" + cadena2;
                    } else {

                        nombre += "-formateado";

                    }
                    String ruta = archivo.getParent();
                    String separador = System.getProperty("file.separator");// para usar propiedades del sistema

                    escritor = new FileWriter(ruta + separador + nombre, true);
                    /* para utilizar la ruta completa y dejarlo en el mismo directorio que el otro archivo.*/

                    outputStream = new BufferedWriter(escritor);

                    /*Escribimos en el segundo */
                    boolean punto = false;
                    String frase;
                    while ((linea = inputStream.readLine()) != null) {
                        frase = "";
                        String[] fraseArray = linea.split(" "); //array de letras
                        for (int i = 0; i < fraseArray.length; i++) {
                            /*Comprobamos si ha guardado en el array algun grupo de espacios */
                            Pattern p = Pattern.compile(" *");
                            Matcher m;
                            m = p.matcher(fraseArray[i]);
                            if (m.matches()) {

                            } else {

                                if (fraseArray[i].contains(".")) {
                                    frase += fraseArray[i];// para que no añada un espacio delante 

                                } else {

                                    String palabra = fraseArray[i];

                                    if (fraseArray[i - 1].equals(".")) {
                                        palabra = StringUtils.capitalize(fraseArray[i]);
                                    }

                                    frase += " " + palabra;
                                }
                            }
                        }
                        frase = frase.trim();//para quitar los espacios delantero.
                        String fraseReal = frase.replace(".", "."); //para que detras de un punto siempre haya un espacio.

                        outputStream.append(fraseReal);
                    }

                    /*     Pattern p=Pattern.compile(" *");
                    Matcher m;
                    m=p.matcher(fraseArray[i]);
                    if(m.matches())
                     */
                    break;

                case 2:
                    archivo = new File(args[0]);
                    lector = new FileReader(archivo);
                    inputStream = new BufferedReader(lector);

                    nombre = archivo.getName();

                    escritor = new FileWriter(args[0]);
                    /* Formateamos en el archivo que el usuario decide*/

                    outputStream = new BufferedWriter(escritor);

                    /*Escribimos en el segundo */
                    String frase2;
                    while ((linea = inputStream.readLine()) != null) {
                        boolean punto2 = false;
                        frase2 = "";
                        String[] fraseArray = linea.split(" "); //array p
                        for (int i = 0; i < fraseArray.length; i++) {
                            /*Comprobamos si ha guardado en el array algun grupo de espacios */
                            Pattern p = Pattern.compile(" *");
                            Matcher m;
                            m = p.matcher(fraseArray[i]);
                            if (m.matches()) {

                            } else {

                                if (fraseArray[i].contains(".")) {
                                    frase2 += fraseArray[i];// para que no añada un espacio delante 

                                } else {

                                    String palabra = fraseArray[i];

                                    if (fraseArray[i - 1].equals(".")) {
                                        palabra = StringUtils.capitalize(fraseArray[i]);
                                    }

                                    frase2 += " " + palabra;
                                }
                            }
                        }

                        frase = frase2.trim();//para quitar los espacios delantero.
                        String fraseReal2 = frase2.replace(".", ". "); //para que detras de un punto siempre haya un espacio.

                        outputStream.append(fraseReal2);
                    }

                    break;
                default:

                    System.out.println("Para usar el programa hacen falta 1 argumento (ruta de fichero)"
                            + " o 2 (2 rutas de fichero) donde el primer fichero sera formateado y escrito en el segundo");
                    break;
            }

        } catch (FileNotFoundException err) {
            System.out.println("Error en archivos.Asegurese que la ruta o las ruta son archivos de texto.");

        } finally {
            if (inputStream != null) {
                inputStream.close();
            }

            if (outputStream != null) {
                outputStream.close();
            }

        }
    }

}
