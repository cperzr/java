/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

import static ad.tema1repaso.Ejer11.f;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.TreeSet;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author Christian
 */
public class Ejer11 {
    static File f=null;
    public static void main(String[]args) throws IOException{
        
        boolean continuar=true;
        
        
        File home=FileSystemView.getFileSystemView().getHomeDirectory();
        String dir=home.getAbsolutePath();
        String barra=System.getProperty("file.separator");
        
        String comprueba=dir+barra+"Empleado";
        
        f= new File(comprueba);
        
        if(!f.exists()){
            f.createNewFile();
        }
        
        do{
            Scanner sc1=new Scanner(System.in);
            System.out.println("Introduce opcion:\n1)Alta de empleado\n2)Baja\n3)modificacion\n4)consulta\n5)Fin de programa");
            int opcion=sc1.nextInt();
            switch (opcion){
                case 1:
                    Alta(f);
                    break;
                case 2:
                    Baja(f);
                    break;
                case 3:
                    Modificado(f);
                    break;
                case 4:
                    Consulta(f);
                    break;
                case 5:
                    Fin();
                    break;    
                default:
                    System.out.println("Opcion no conemplada");
                    break;
            }
        }while(continuar);
    }
    private static void Alta(File f){
        Scanner sc=new Scanner(System.in);
        TreeSet <String> arbol=new TreeSet();
        int cont=0;
        try{
            FileReader fr=new FileReader(f);//objeto de lectura
            BufferedReader BR=new BufferedReader(fr);
            String linea;
            while((linea=BR.readLine())!=null){
                int total=linea.length();
                String num=linea.substring((total-1),total);
                cont=((int)Integer.parseInt(num))+1;
                arbol.add(linea);
                
            }
            BR.close();
            fr.close();
            if(arbol.size()==0){
                cont=1;                
            }
            
            fr.close();//importante cerrar lectura entes de escritura
            System.out.println("escritura");
            System.out.println("Introduce nombre simple");
            String nom=sc.nextLine();
            System.out.println("Apellido 1");
            String ap1=sc.nextLine();
            System.out.println("Apellido 2");
            String ap2=sc.nextLine();
            System.out.println("Departamento");
            String dep1=sc.nextLine();
            System.out.println("ciudad");
            String ciu=sc.nextLine();
            System.out.println("Salario");
            String sal=sc.nextLine();
            
            String Todo=nom+";"+ap1+";"+ap2+";"+dep1+";"+ciu+";"+sal+";"+cont;
            //String Todo="1;hola;sanchez;lopez;con;cad;100";
            arbol.add(Todo);
            
            FileWriter fw=new FileWriter(f);
            BufferedWriter BW=new BufferedWriter(fw);
            for(String a:arbol){
                BW.write(a+"\n");
            }
                BW.close();
            fw.close();//no olvidar de cerrar
        }catch(IOException e){}
    }
    
        
   private static void Baja(File f){
        Scanner sc=new Scanner(System.in);
        TreeSet <String> arbol=new TreeSet();
        int cont;
        int id=1;
        try{
            
            FileReader fr=new FileReader(f);//objeto de lectura
            BufferedReader BR=new BufferedReader(fr);
            String linea;
            while((linea=BR.readLine())!=null){
                int total=linea.length();
                String num=linea.substring((total-1),total);
                id=((int)Integer.parseInt(num));
                System.out.println(linea+" con id:"+id);
                arbol.add(linea);
                id++;
            }
            
            BR.close();
            fr.close();
            
            FileWriter fw=new FileWriter(f);
            BufferedWriter BW=new BufferedWriter(fw);
            
            System.out.println("Introduce id de empleado a borrar:");
            cont=sc.nextInt();
            boolean borrado=false;
            for(String a:arbol){
                int total=a.length();
                String num=a.substring((total-1),total);
                int idcont=((int)Integer.parseInt(num));
                if(cont!=idcont){
                    BW.write(a+"\n");
                }else{
                    borrado=true;
                }
                
            }
            if(borrado){
                System.out.println("Borrado correcto");
            }else{
                System.out.println("Error en borrado, id no encontrado");
            }
            BW.close();
            fw.close();//no olvidar de cerrar
        }catch(IOException e){}
    }
    private static void Modificado(File f){
        Scanner sc=new Scanner(System.in);
        TreeSet <String> arbol=new TreeSet();
        int cont;
        int id;
        try{
            //leemos para almacenar y mostrar al usuario los empleados
            FileReader fr=new FileReader(f);//objeto de lectura
            BufferedReader BR=new BufferedReader(fr);
            String linea;
            while((linea=BR.readLine())!=null){
                int total=linea.length();
                String num=linea.substring((total-1),total);
                id=((int)Integer.parseInt(num));
                System.out.println(linea+" con id:"+id);
                arbol.add(linea);
            }
            
            BR.close();
            fr.close();
            System.out.println("Introduce id de empleado a modificar:");
            cont=sc.nextInt();
   
            
            FileWriter fw=new FileWriter(f);
            BufferedWriter BW=new BufferedWriter(fw);
            
            
            boolean borrado=false;
            for(String a:arbol){
                int total=a.length();
                String num=a.substring((total-1),total);
                int idcont=((int)Integer.parseInt(num));
                if(cont==idcont){
                    System.out.println("escritura");
                    sc.nextLine();
                    System.out.println("Introduce nombre simple");
                    String nom=sc.nextLine();
                    System.out.println("Apellido 1");
                    String ap1=sc.nextLine();
                    System.out.println("Apellido 2");
                    String ap2=sc.nextLine();
                    System.out.println("Departamento");
                    String dep1=sc.nextLine();
                    System.out.println("ciudad");
                    String ciu=sc.nextLine();
                    System.out.println("Salario");
                    String sal=sc.nextLine();
            
                    String Todo=nom+";"+ap1+";"+ap2+";"+dep1+";"+ciu+";"+sal+";"+idcont;
                    BW.write(Todo+"\n");
                    borrado=true;
                }else{
                    BW.write(a+"\n");
                }
                
            }
            if(borrado){
                System.out.println("Borrado correcto");
            }else{
                System.out.println("Error en modificacion id no encontrado");
            }
            BW.close();
            fw.close();//no olvidar de cerrar
        }catch(IOException e){}
    }
    private static void Consulta(File f){
        Scanner sc=new Scanner(System.in);
        TreeSet <String> arbol=new TreeSet();
        int cont;
        int id;
        try{
            
            FileReader fr=new FileReader(f);//objeto de lectura
            BufferedReader BR=new BufferedReader(fr);
            String linea;
            while((linea=BR.readLine())!=null){
                int total=linea.length();
                String num=linea.substring((total-1),total);
                id=((int)Integer.parseInt(num));
                System.out.println(" con id:"+id+"\n\t->"+linea);
            }
            
            BR.close();
            fr.close();
        }catch(IOException e){}
    }
    private static void Fin(){
        System.out.println("Fin de programa");
        System.exit(0);
    }
}
