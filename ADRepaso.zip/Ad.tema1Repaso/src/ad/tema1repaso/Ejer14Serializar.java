/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

/**
 *
 * @author Christian
 */
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

public class Ejer14Serializar {

    public void serializarEmpleado() throws IOException {
        FileInputStream fileEntrada = null;
        DataInputStream dataEntrada = null;

        Empleado emp = null;

        File fichero1 = null;
        FileOutputStream fileout = null;// serializar en bytes por lo tanto abrimos un output para bytes.
        ObjectOutputStream dataOS = null; // es el que lee escribe el objeto
        try {
            fichero1 = new File("C:\\Users\\Christian\\Desktop\\FicheroEmpleados");
            fichero1.createNewFile();
            fileout = new FileOutputStream(fichero1);
            dataOS = new ObjectOutputStream(fileout);

            fileEntrada = new FileInputStream("C:\\Users\\Christian\\Desktop\\Empleados");

            dataEntrada = new DataInputStream(fileEntrada);
            int id = -1;
            String nombreEmp = "";
            String ap1="";
            String ap2="";
            String depEmp = "";
            String ciudadEmp = "";
            double salarioEmp = 0.00;

            while (fileEntrada.available() > 0) {
                id = dataEntrada.readInt();
                nombreEmp = dataEntrada.readUTF();
                ap1=dataEntrada.readUTF();
                ap2=dataEntrada.readUTF();
                depEmp = dataEntrada.readUTF();
                ciudadEmp = dataEntrada.readUTF();
                salarioEmp = dataEntrada.readDouble();

                emp = new Empleado(nombreEmp,ap1,ap2, 1, depEmp);

                dataOS.writeObject(emp); //El objeto "emp" debe ser instancia de una
                //clase que implemente la interfaz 'Serializable'

                dataOS.close();
            }
        } catch (Exception e) {
        } finally {
            if (fileEntrada != null) {
                fileEntrada.close();
            }
            if (dataEntrada != null) {
                dataEntrada.close();
            }

            if (fileout != null) {
                fileout.close();
            }// serializar en bytes por lo tanto abrimos un output para bytes.
            if (dataOS != null) {
                dataOS.close();
            }

        }

    }

    public void desserializarEmpleado() throws IOException {

        Empleado emp = null;

        File fichero2 = null;
        FileInputStream filein = null;// serializar en bytes por lo tanto abrimos un output para bytes.
        ObjectInputStream dataIS = null; // es el que lee escribe en el objeto
        try {
            fichero2 = new File("C:\\Users\\Christian\\Desktop\\FicheroEmpleados");
            filein = new FileInputStream(fichero2);
            dataIS = new ObjectInputStream(filein);
            while (filein.available() > 0) {
                emp = (Empleado) dataIS.readObject();
                dataIS.close();
                emp.mostrarEmpleado();

            }
        } catch (Exception e) {
        } finally {

            if (filein != null) {
                filein.close();
            }// serializar en bytes por lo tanto abrimos un output para bytes.
            if (dataIS != null) {
                dataIS.close();
            }

        }

    }

    private class Empleado implements Serializable {

        private String nombre;
        private String ap1;
        private String ap2;
        private int edad;
        private String departamento;

        public Empleado(String nombre,String ap1 ,String ap2 , int edad, String departamento) {
            this.nombre = nombre;
            this.ap1=ap1;
            this.ap2=ap2;
            this.edad = edad;
            this.departamento = departamento;
        }

        public Empleado() {
            this.nombre = null;
            this.edad = 0;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }
        public void setAp1(String ap1) {
            this.ap1 = ap1;
        }
        public void setAp2(String ap2) {
            this.ap2 = ap2;
        }

        public void setEdad(int edad) {
            this.edad = edad;
        }

        public void setDepartamento(String departamento) {
            this.departamento = departamento;
        }

        public String getNombre() {
            return nombre;
        }
        public String getAp1() {
            return ap1;
        }
        public String getAp2() {
            return ap2;
        }

        public int getEdad() {
            return edad;
        }

        public String getDepartamento() {
            return departamento;
        }

        public void mostrarEmpleado() {
            System.out.println(getNombre() + ","+ getAp1()+" ,"+getAp2()+" ,"+ getEdad() + " , " + getDepartamento());
        }

    }

    public static void main(String args[]) throws IOException {
        Ejer14Serializar se = new Ejer14Serializar();

        se.serializarEmpleado();

        System.out.println("Quiere desserializar el empleado y mostrarlo?(s/n)");
        Scanner sc = new Scanner(System.in);
        if (sc.nextLine().toLowerCase().equals("s")) {

            se.desserializarEmpleado();
        }

    }

}
