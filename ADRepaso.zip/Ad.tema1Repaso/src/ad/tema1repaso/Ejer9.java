/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.TreeSet;

/**
 *
 * @author Christian
 */
public class Ejer9 {
    static String FicLecEsc=null;
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Introduce la direccion del fichero");
        FicLecEsc=sc.nextLine();
        
        File origen;
        origen = new File(FicLecEsc);
        if(!origen.exists()){
            System.out.println("Fichero no existente");
            System.exit(0);
        }
        TreeSet <String> arbol=new TreeSet();
        try{
            FileReader fr=new FileReader(origen);//objeto de lectura
            int valor=fr.read();//variable en ña que leemos todo el documento
            char caracter;//donde almacenaremos los caracteres
            String nombre="";//acumulador de caracteres donde conseguiremos el nombre
            while(valor!=-1){//bucle para rellenar los nombres y meterlos en una coleccion
                nombre+=(char)valor;//convertimos en string y guardamos junto a los anteriores
                if(valor=='\n'){//cuando tenemos el separador lo añadimos a la coleccion
                    arbol.add(nombre);//lo añadimos
                    nombre="";//reseteamos
                }
            }
            
            fr.close();//importante cerrar lectura entes de escritura
            FileWriter fw=new FileWriter(origen);
            boolean continua=true;
            nombre="";
            do{
                System.out.println("introduce alumno: \n-13 para terminar");
                String intro=sc.nextLine();
                if(intro.equals("-13")){
                    System.out.println("Fin de programa");
                    continua=false;
                    break;
                }
                nombre+=intro+"\n";
                arbol.add(nombre);
                nombre="";
            }while(continua);
            
            for(String e:arbol){//iterator
                fw.write(e);
            }
            fw.close();
        }catch(IOException e){}
    }
}
