/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

import java.io.File;
import java.util.Arrays;

/**
 *
 * @author Christian
 */
public class Ejer3EjerostrarDirectorioActual3 {
    private static void mostrarAyuda(){
        System.out.println("En la ruta especificada no hay directorio");
    }
    public static void main(String[] args) {
        System.out.println("mostrar directorios");
        if(args[0].equals("-h")){
            mostrarAyuda();
            return;
        }
        
        File f= new File(args[0]);
        String [] listaFicheros=f.list(); //La lista nunca estar� vac�a (al menos contendr� "." y "..")
        Arrays.sort(listaFicheros);
        
        if(f.exists()){
            if(f.isFile()){System.out.println(f.getName());}            
        }else if(f.isDirectory()){
            for(int i=0; i<listaFicheros.length; i++){
                System.out.println(listaFicheros[i]);
            } 
        }
    }
}
