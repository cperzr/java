/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.tema1repaso;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Christian
 */
public class Ejer8 {
    static String origen;
    static String destino;
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Introduce la direccion del archivo a copiar");
        origen=sc.nextLine();
        System.out.println("Introduce la direccion del archivo destino");
        destino=sc.nextLine();
        File org=new File(origen);
        File dest=new File(destino);
        try {
            FileReader fr=new FileReader(org);//declaro el constructor de lectura
            FileWriter fw=new FileWriter(dest);//declaro el constructor de escritura
            int valor;//leemos fichero
            char car;//caracter que vamos a estar leyendo en cada momento
            String caracter="";
            String caracterM="";
            while((valor=fr.read())!=-1){//valor=fr.read() para asegurar de que va avanzando y no es un bucle infinito
                car=((char)valor);//asignamos
                caracter=Character.toString(car);//pasamos a string para hacer el toUppercase()
                caracterM+=caracter.toUpperCase();//hacemos el toUppercase();
                
            }
            fr.close();//cuando terminamos de leer cerramos 
            char escribe[]=caracterM.toCharArray();//Pasamos a char la cadena a escribir
            fw.write(escribe);//escribimos
            fw.close();//cerramos tras la escritura
            
        }catch (IOException e){}
    }
}
