/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EjerciciosT2;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Christian
 */
public class DataBaseMetaDataEjercicio {

    static String sqlite_jdbd_driver = "org.sqlite.JDBC";
    static String prefix = "jdbc:" + "sqlite:";
    static String hostName = "";
    static String urlFolder = "C:\\Users\\Christian\\Desktop\\2ºDAM\\Acceso a datos\\Tema2\\SqlLiteyapachederby\\";
    static String driver = sqlite_jdbd_driver;
    static String user = ""; //"user";
    static String password = "";
    static Connection con;
    //esta dbName es para la de por defecto
    static String dbName = "ejemplo1.db";

    //El nombre de la BD que el usuario va a introducir
    static String dbNameUsu = "ejemplo1.db";
    //static String url = prefix + hostName + urlFolder + dbName;

    DatabaseMetaData dbmd;

    public static void main(String[] args) {
        DataBaseMetaDataEjercicio clase = new DataBaseMetaDataEjercicio();
    }

    public DataBaseMetaDataEjercicio() {
        IniciarPrograma();
    }

    private void IniciarPrograma() {
        int opcion;
        do {
            ImprMenu();
            opcion = OpSelec();
            if (opcion == 4) {
                return;
            }
        } while (opcion < 1 || opcion > 4);

        //despues de capturar el dato de la opcion lo enviamos al Swicht
        switch (opcion) {
            case 1:
                buscaBD();
                IniciarPrograma();
                break;
            case 2:
                infoConexBD();
                IniciarPrograma();
                break;
            case 3:
                buscaTablaBD();
                IniciarPrograma();
                break;
            case 4:
                System.out.println("Fin de programa");
                break;
        }
    }

    private Connection metodoConectar(String dbNameUsu) {
        String url = prefix + hostName + urlFolder + dbNameUsu;
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url, user, password);
            return con;
        } catch (ClassNotFoundException cnfe) {
            System.out.printf("Not found the jdbc driver %s\n", driver);
            return con;
        } catch (SQLException of0) {
            System.out.println("SQL Exception");
            return con;
        }
    }

    private void buscaBD() {
        //Comprobar si existe una base de datos recibe dbname
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce nombre de la base de datos");
        dbNameUsu = sc.nextLine();
        con = null;
        con = metodoConectar(dbNameUsu);
        String catalogo;
        if (con != null) {
            try {
                dbmd = con.getMetaData();
                ResultSet result = dbmd.getTables(null, dbName, null, null);
                while (result.next()) {
                    catalogo = result.getString("TABLE_CAT");
                    System.out.println("Existe la base de datos con nombre: " + dbNameUsu + "\nCatalogo:\n\t" + catalogo);
                }
            } catch (SQLException ex) {
                System.out.println("Metadatas fallido");
            }
        } else {
            System.out.println("NO existe la base de datos con nombre: " + dbNameUsu);
        }

    }

    private void infoConexBD() {
        //Mostrar la información de conexión con una BD (motor, driver, url, usuario y máquina)
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce nombre de la base de datos");
        dbNameUsu = sc.nextLine();
        con = null;
        con = metodoConectar(dbNameUsu);
        String catalogo;
        if (con != null) {
            try {
                dbmd = con.getMetaData();
                String nombre = dbmd.getDatabaseProductName(); //DB engine
                String driver = dbmd.getDriverName();          //JDBC driver
                String url = dbmd.getURL();                 //protocolo://IP/ruta/nombreBD
                String usuario = dbmd.getUserName();			//usuario@m�quina

                System.out.println("");
                System.out.println("INFORMACI�N GENERICA SOBRE EL SGBD y el driver JDBC");
                System.out.println("===================================================");
                System.out.println("Nombre : " + nombre);
                System.out.println("Driver : " + driver);
                System.out.println("URL    : " + url);
                System.out.println("Usuario: " + usuario);
            } catch (SQLException ex) {
                System.out.println("Metadatas fallido");
            }
        } else {
            System.out.println("NO existe la base de datos con nombre: " + dbNameUsu);
        }

    }

    private void buscaTablaBD() {
        //Dado un patron (Utilizando el caracter comodín '%' obtener todas las tablas/vistas de la BD actual que encaje con ese patrón)
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce nombre de la base de datos");
        dbNameUsu = sc.nextLine();
        System.out.println("Introduce patron [si empieza por d-> d%]");
        String patron = sc.nextLine();
        con = null;
        con = metodoConectar(dbNameUsu);
        String tabla;
        if (con != null) {
            try {
                dbmd = con.getMetaData();
                ResultSet result = dbmd.getTables(null, dbName, patron, null);
                while (result.next()) {
                    tabla=result.getString("TABLE_NAME");
                    System.out.println("Nombre de tabla: "+tabla);
                    }
            } catch (SQLException ex) {
                System.out.println("Metadatas fallido");
            }
        } else {
            System.out.println("NO existe la base de datos con nombre: " + dbNameUsu);
        }
    }

    private void ImprMenu() {
        System.out.println("-------MENU-----");
        System.out.println("1)Comprobar si existe una base de datos");
        System.out.println("2)Mostrar la información de conexión con una BD (motor, driver, url, usuario y máquina)");
        //System.out.println("3)"); este no
        System.out.println("3)Dado un patron (Utilizando el caracter comodín '%' obtener todas las tablas/vistas de la BD actual que encaje con ese patrón)");
        System.out.println("4)Salir");
        System.out.println("\nIntroduce opcion: [Numero entero]");
    }

    private int OpSelec() {
        Scanner sc = new Scanner(System.in);
        int OpEle = 0;
        try {
            OpEle = sc.nextInt();
        } catch (InputMismatchException e) {
            OpEle = 0;
            sc.nextLine();
            System.out.println("ERROR, Caracter introducido no numerico");
        }
        return OpEle;
    }

}
