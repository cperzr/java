/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.



    Realizar un programa que permita obtener, para cada departamento, el APELLIDO y SALARIO de los empleados
    cuyo salario representa los cuartiles Q1, Q2, Q3 de los salarios de los empleados del departamento
    (Q1: salario del primer empleado con un salario >= 25% de los empleados del departamento
     Q2: salario del primer empleado con un salario >= 50% de los empleados del departamento (mediana)
     Q3: salario del primer empleado con un salario >= 75% de los empleados del departamento)
 */
package EjerciciosT2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Christian
 */
public class Ejercicio6 {

    static String sqlite_jdbd_driver = "org.sqlite.JDBC";
    static String prefix = "jdbc:" + "sqlite:";
    static String hostName = "";
    static String urlFolder = "C:\\Users\\Christian\\Desktop\\2ºDAM\\Acceso a datos\\Tema2\\SqlLiteyapachederby\\";

    static String driver = sqlite_jdbd_driver;

    static String user = ""; //"user";
    static String password = "";
    
    static String dbName = "ejemplo1.db";
    
    static String url = prefix + hostName + urlFolder + dbName;

    public static void main(String[] args) {
        statementQueryExample();

    }

    public static void statementQueryExample() {
        //6)Realizar un programa que permita obtener, para cada departamento, el APELLIDO y SALARIO de los empleados
//    cuyo salario representa los cuartiles Q1, Q2, Q3 de los salarios de los empleados del departamento
//    (Q1: salario del primer empleado con un salario >= 25% de los empleados del departamento
//     Q2: salario del primer empleado con un salario >= 50% de los empleados del departamento (mediana)
//     Q3: salario del primer empleado con un salario >= 75% de los empleados del departamento)
//            "SELECT d.dnombre,"
//                    + "e.apellido,e.salario "
//                    + "FROM empleados e,departamentos d WHERE d.dept_no=e.dept_no AND"
//            + " (e.salario>=(25*100)/(SELECT MAX(salario)from empleados LIMIT 1;)) "
//            + "OR (e.salario>=(50*100)/(SELECT MAX(salario)from empleados LIMIT 1;)) "
//            + "OR (e.salario>=(75*100)/(SELECT MAX(salario)from empleados LIMIT 1;)) "
//            + "ORDER BY d.dnombre,e.salario";
//            //
        {
            String queryQ1 = "SELECT d.dnombre,"
                    + "(SELECT apellido FROM empleados WHERE dept_no=d.dept_no AND (salario>=(0.25)*(SELECT MAX(salario)from empleados WHERE dept_no=d.dept_no LIMIT 1)) ORDER BY salario asc LIMIT 1 ) apellidoQ1,"
                    + "(SELECT salario FROM empleados WHERE dept_no=d.dept_no AND (salario>=(0.25)*(SELECT MAX(salario)from empleados WHERE dept_no=d.dept_no LIMIT 1)) ORDER BY salario asc LIMIT 1) salarioQ1 "
                    + "FROM empleados e,departamentos d WHERE d.dept_no=e.dept_no GROUP BY d.dnombre";

            String queryQ2 = "SELECT d.dnombre,"
                    + "(SELECT apellido FROM empleados WHERE dept_no=d.dept_no AND (salario>=(0.50)*(SELECT MAX(salario)from empleados WHERE dept_no=d.dept_no LIMIT 1)) ORDER BY salario asc LIMIT 1) apellidoQ1,"
                    + "(SELECT salario FROM empleados WHERE dept_no=d.dept_no AND (salario>=(0.5)*(SELECT MAX(salario)from empleados WHERE dept_no=d.dept_no LIMIT 1)) ORDER BY salario asc LIMIT 1) salarioQ1 "
                    + "FROM empleados e,departamentos d WHERE d.dept_no=e.dept_no GROUP BY d.dnombre";

            String queryQ3 = "SELECT d.dnombre,"
                    + "(SELECT apellido FROM empleados WHERE dept_no=d.dept_no AND (salario>=(0.75)*(SELECT MAX(salario)from empleados WHERE dept_no=d.dept_no LIMIT 1)) ORDER BY salario asc LIMIT 1) apellidoQ1,"
                    + "(SELECT salario FROM empleados WHERE dept_no=d.dept_no AND (salario>=(0.75)*(SELECT MAX(salario)from empleados WHERE dept_no=d.dept_no LIMIT 1)) ORDER BY salario asc LIMIT 1) salarioQ1 "
                    + "FROM empleados e,departamentos d WHERE d.dept_no=e.dept_no GROUP BY d.dnombre";

            try {
                //Load the driver in RAM
                Class.forName(driver);

                //Connect to DB
                Connection connection = DriverManager.getConnection(url, user, password);
                //primer quartir
                Statement statement1 = connection.createStatement();
                ResultSet result1 = statement1.executeQuery(queryQ1);
                //segundo quartir
                Statement statement2 = connection.createStatement();
                ResultSet result2 = statement2.executeQuery(queryQ2);
                //tercero quartir
                Statement statement3 = connection.createStatement();
                ResultSet result3 = statement3.executeQuery(queryQ3);

                //Iterate on the 'ResultSet' to process each row
                while (result1.next()) {//There are still rows to get
                    System.out.println(result1.getString(1)
                            + "\n\t\t ApellidoQ1= " + result1.getString(2) + "\t SalarioApellidoQ1= " + result1.getDouble(3));
                    if (result2.next()) {
                        System.out.println("\t\t ApellidoQ2= " + result2.getString(2) + "\t SalarioApellidoQ1= " + result2.getDouble(3));
                    }
                    if (result3.next()) {
                        System.out.println("\t\t ApellidoQ3= " + result3.getString(2) + "\t SalarioApellidoQ1= " + result3.getDouble(3));
                    }
                }

                result1.close(); //close ResultSet
                statement1.close();//close Statement

                result2.close(); //close ResultSet
                statement2.close();//close Statement

                result3.close(); //close ResultSet
                statement3.close();//close Statement

                connection.close();//close Connection

            } catch (ClassNotFoundException cnfe) {
                System.out.printf("Not found the jdbc driver %s\n", driver);
            } catch (SQLException sqle) {
                System.out.println("SQL Exception");
            }
        }

    }
}
