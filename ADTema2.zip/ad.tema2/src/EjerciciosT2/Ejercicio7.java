/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EjerciciosT2;

import static EjerciciosT2.Ejercicio6.driver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.*;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Christian
 */
public class Ejercicio7 {

    /*
    Conexcion    
     */
    static String dbName = "prueba";
    static String parameters = "";

    static String MySQL_jdbcDriver = "com.mysql.jdbc.Driver";
    static String protocol = "jdbc:" + "mysql:";
    static String hostName = "localhost";

    //static parameters= "noAccessToPocedureBodies=true";
    static String MySQL_url = "jdbc:mysql://localhost/" + dbName;

    //Actual DB parameters
    static String driver = MySQL_jdbcDriver;
    static String url = MySQL_url;

    static String user = "root";
    static String password = "";

    /*
    sentencias para alta/baja/mod/consulta
     */
    //ALTAS
    String altaEmple = "INSERT INTO empleados (apellido,oficio,salario,fecha_alt) VALUES (?,?,?,?);"; //fecha se guarda como YYYY/MM/dd
    String altaDepto = "INSERT INTO departamentos (dnombre,loc) VALUES (?,?);";

    //BAJAS
    String bajaEmple = "DELETE FROM empleados WHERE emp_no=?;";
    String bajaDepto = "DELETE FROM departamentos WHERE dept_no=?;";
    //MOD POR ID
    String modEmple = "UPDATE empleados SET apellido=? , dept_no=? , oficio=?,salario=? WHERE emp_no=?";
    String modDepto = "UPDATE departamentos SET dnombre=? , loc=?  WHERE dept_no=?";
    //consultas por ID
    String consultaEmple = "SELECT emp_no, apellido, oficio,salario ,fecha_alt FROM empleados WHERE apellido LIKE ?";
    String consultaDepto = "SELECT dept_no , dnombre, loc FROM departamentos WHERE dnombre LIKE ?";

    String consDNombre = "SELECT dnombre FROM departamentos WHERE dnombre=?";
    String consDId = "SELECT dept_no FROM departamentos WHERE dept_no=?";

    String consEId = "SELECT emp_no FROM empleados WHERE emp_no=?";
    /*---------------------------------------------------------------------*/
    String fecha = "";
    Scanner sc = new Scanner(System.in);
    static Ejercicio7 gestor = new Ejercicio7();

    public static void main(String[] args) {

        gestor.iniciarGestor();

    }

    public String cogerFechaActual() {
        Date fechaActual = new Date();
        DateFormat formatoFecha = new SimpleDateFormat("YYYY/MM/dd");
        fecha = "" + formatoFecha.format(fechaActual);
        return fecha;
    }

    private void imprimirMenuPrincipal() {
        System.out.println("¿Que quiere realizar?");
        System.out.println("1.Trabajar con la tabla Departamento");
        System.out.println("2.Trabajar con la tabla Empleado");
        System.out.println("3.Salir");

    }

    private void iniciarGestor() {
        cogerFechaActual();
        imprimirMenuPrincipal();

        int opcionMenu1;
        opcionMenu1 = opcionMenu1();

        switch (opcionMenu1) {
            case 1:
                iniciarMenuDepartamento();
                break;

            case 2:
                iniciarMenuEmpleado();
                break;

            case 3://al no utilizar nada termina automaticamente
                break;

        }

    }

    private int opcionMenu1() {
        int opcion = 1;

        do {
            System.out.print("Introduzca opcion : ");
            System.out.println();
            try {
                opcion = sc.nextInt();
            } catch (InputMismatchException ex) {
                System.out.println("¡ERROR! Introduzca un numero por favor");
                sc.nextLine();
                opcion = 20;
            }
            if (opcion < 1 || opcion > 3) {
                System.out.println("El numero : " + opcion + " No es una opcion valida");
            }

        } while (opcion < 1 || opcion > 3);
        return opcion;
    }

    private void iniciarMenuDepartamento() {
        System.out.println("Trabajando en tabla DEPARTAMENTO");
        imprimirMenu2();
        switchDept();

    }

    private void iniciarMenuEmpleado() {
        System.out.println("Trabajando en tabla EMPLEADO");
        imprimirMenu2();
        switchEmp();

    }

    private void imprimirMenu2() {
        System.out.println("1 Dar de Alta ");
        System.out.println("2 Dar de Baja");
        System.out.println("3 Modificar  Completo");
        System.out.println("4 Consultar por nombre (pueden aparecer varios)");
        System.out.println("5 Dejar de trabajar con la tabla actual, volver al Menu Principal.");

    }

    private void gestionarOpcionesMenu2(String tabla) {
        if (tabla.equals("DEPARTAMENTO")) {
            switchDept();
        } else {
            switchEmp();
        }

    }

    private void switchDept() {
        int opcionSwitch = opcionMenu2();
        switch (opcionSwitch) {
            case 1:
                AltaDep();
                iniciarMenuDepartamento();
                break;
            case 2:
                BajaDep();
                iniciarMenuDepartamento();
                break;
            case 3:
                ModDep();
                iniciarMenuDepartamento();
                break;
            case 4:
                ConsDep();
                iniciarMenuDepartamento();
                break;
            case 5:
                iniciarGestor();
                break;
        }

    }

    private void switchEmp() {

        int opcionSwitch = opcionMenu2();
        switch (opcionSwitch) {
            case 1:
                AltaEmp();
                iniciarMenuEmpleado();
                break;
            case 2:
                BajaEmp();
                iniciarMenuEmpleado();
                break;
            case 3:
                ModEmp();
                iniciarMenuEmpleado();
                break;
            case 4:
                ConsEmp();
                iniciarMenuEmpleado();
                break;
            case 5:
                iniciarGestor();
                break;
        }

    }

    private int opcionMenu2() {
        int opcion = 1;
        do {
            System.out.print("Introduzca opcion : ");
            System.out.println();
            try {
                opcion = sc.nextInt();
            } catch (InputMismatchException ex) {
                System.out.println("¡ERROR! Introduzca un numero por favor");
                sc.nextLine();
                opcion = 20;
            }
            if (opcion < 1 || opcion > 5) {
                System.out.println("El numero : " + opcion + " No es una opcion valida");
            }
        } while (opcion < 1 || opcion > 5);
        return opcion;
    }
//opciones de empleados

    private void AltaEmp() {
        PreparedStatement inEmp = null;
        Connection connection = null;
        Scanner sc2 = new Scanner(System.in);
        try {
            Class.forName(driver);
            //Connect to DB
            connection = DriverManager.getConnection(url, user, password);

            String apellido = "";
            String oficio = "";
            double salario = 0.0;
            String fecha2 = cogerFechaActual();
            do {
                System.out.println("Introduce apellido:");
                apellido = sc2.nextLine().toUpperCase();
            } while (apellido.equals("") || apellido == null);
            do {
                System.out.println("Introduce oficio:");
                oficio = sc2.nextLine();
            } while (oficio.equals("") || oficio == null);
            do {
                try {
                    System.out.println("Introduce salario:");
                    salario = sc2.nextDouble();
                } catch (InputMismatchException eo) {
                    sc.nextLine();
                    salario = -1.0;
                }
            } while (salario <= 0);

            inEmp = connection.prepareStatement(altaEmple);
            inEmp.setString(1, apellido);
            inEmp.setString(2, oficio);
            inEmp.setDouble(3, salario);
            inEmp.setString(4, fecha2);

            inEmp.executeUpdate();
        } catch (Exception e) {
        } finally {
            try {
                inEmp.close();
                connection.close();
            } catch (Exception yu) {
            }
        }
    }

    private void BajaEmp() {
        Scanner sc2 = new Scanner(System.in);
        PreparedStatement inDep = null;
        Connection connection = null;
        boolean idRepetido = false;
        try {
            Class.forName(driver);
            //Connect to DB
            connection = DriverManager.getConnection(url, user, password);

            int Empno = 0;
            do {
                System.out.println("Introduce Id del Empleado a borrar");
                Empno = sc2.nextInt();
                idRepetido = existedatoInt(Empno, consEId);
            } while (Empno == 0 || idRepetido == false);

            inDep = connection.prepareStatement(bajaEmple);
            inDep.setInt(1, Empno);

            inDep.executeUpdate();
        } catch (Exception e) {
        } finally {
            try {
                inDep.close();
                connection.close();
            } catch (Exception yu) {
            }
        }
    }

    private void ModEmp() {
        Scanner sc2 = new Scanner(System.in);
        Scanner sc3 = new Scanner(System.in);
        PreparedStatement UpEm = null;
        Connection connection = null;
        boolean idRepetido = false;
        try {
            Class.forName(driver);
            //Connect to DB
            connection = DriverManager.getConnection(url, user, password);

            int Empid = 0;
            do {
                System.out.println("Introduce el ID del Empleado/Empleados a modificar");
                Empid = sc3.nextInt();
                idRepetido = existedatoInt(Empid, consEId);
            } while (Empid == 0 || idRepetido == false);

            String apellido = "";
            String oficio = "";
            double salario = 0.0;
            int depart = 0;
            boolean mira = false;
            do {
                System.out.println("Introduce apellido:");
                apellido = sc2.nextLine();
            } while (apellido.equals("") || apellido == null);
            do {
                System.out.println("Introduce oficio:");
                oficio = sc2.nextLine();
            } while (oficio.equals("") || oficio == null);
            do {
                try {
                    System.out.println("Introduce Departamento existente:");
                    depart = sc3.nextInt();
                    mira = existedatoInt(depart, consDId);
                } catch (InputMismatchException eo) {
                    sc.nextLine();
                    depart = 0;
                }
            } while (depart <= 0 || mira == false);
            do {
                try {
                    System.out.println("Introduce salario:");
                    salario = sc3.nextDouble();
                } catch (InputMismatchException eo) {
                    sc.nextLine();
                    salario = -1.0;
                }
            } while (salario <= 0);

            UpEm = connection.prepareStatement(modEmple);
            UpEm.setString(1, apellido);
            UpEm.setInt(2, depart);//depart
            UpEm.setString(3, oficio);
            UpEm.setDouble(4, salario);

            UpEm.setInt(5, Empid);
            UpEm.executeUpdate();

        } catch (Exception e) {
        } finally {
            try {
                UpEm.close();
                connection.close();
            } catch (Exception yu) {
            }
        }
    }

    private void ConsEmp() {
        Scanner sc2 = new Scanner(System.in);
        PreparedStatement inDep = null;
        Connection connection = null;
        boolean idRepetido = false;
        try {
            Class.forName(driver);
            //Connect to DB
            connection = DriverManager.getConnection(url, user, password);

            String Empno = "";
            do {
                System.out.println("Introduce Nombre del Empleado/Empleados a mostrar");
                Empno = sc2.nextLine().toUpperCase();
                idRepetido = existedatoString(Empno, consEId);
            } while (Empno.equals("") || idRepetido == true);
            String ApelFin = "%" + Empno + "%";
            inDep = connection.prepareStatement(consultaEmple);
            inDep.setString(1, ApelFin);

            ResultSet rs = inDep.executeQuery();
            int con = 1;
            while (rs.next()) {
                System.out.println(con + ")->\tID: " + rs.getInt(1) + ", Apellido: " + rs.getString(2) + ", Oficio: " + rs.getString(3) + ", Salario: " + rs.getFloat(4) + ", Fecha de alta: " + rs.getString(5));
            }
        } catch (Exception e) {
        } finally {
            try {
                inDep.close();
                connection.close();
            } catch (Exception yu) {
            }
        }
    }

//opciones de departamento
    private void AltaDep() {
        Scanner sc2 = new Scanner(System.in);
        PreparedStatement inDep = null;
        Connection connection = null;
        try {
            Class.forName(driver);
            //Connect to DB
            connection = DriverManager.getConnection(url, user, password);

            String dnombre = "";
            String loc = "";
            boolean nombRepetido = false;
            do {
                System.out.println("Introduce nombre de departamento:");
                dnombre = sc2.nextLine().toUpperCase();
                nombRepetido = existedatoString(dnombre, consDNombre);
            } while (dnombre.equals("") || nombRepetido == true);
            do {
                System.out.println("Introduce localizacion:");
                loc = sc2.nextLine().toUpperCase();
            } while (loc.equals("") || loc == null);

            inDep = connection.prepareStatement(altaDepto);
            inDep.setString(1, dnombre);
            inDep.setString(2, loc);

            inDep.executeUpdate();
        } catch (Exception e) {
        } finally {
            try {
                inDep.close();
                connection.close();
            } catch (Exception yu) {
            }
        }
    }

    private void BajaDep() {
        Scanner sc2 = new Scanner(System.in);
        PreparedStatement inDep = null;
        Connection connection = null;
        boolean idRepetido = false;
        try {
            Class.forName(driver);
            //Connect to DB
            connection = DriverManager.getConnection(url, user, password);

            int depNo = 0;
            do {
                System.out.println("Introduce Id del departamento a borrar");
                depNo = sc2.nextInt();
                idRepetido = existedatoInt(depNo, consDId);
            } while (depNo == 0 || idRepetido == false);

            inDep = connection.prepareStatement(bajaDepto);
            inDep.setInt(1, depNo);

            inDep.executeUpdate();
        } catch (Exception e) {
        } finally {
            try {
                inDep.close();
                connection.close();
            } catch (Exception yu) {
            }
        }
    }

    private void ModDep() {
        Scanner sc2 = new Scanner(System.in);
        Scanner sc3 = new Scanner(System.in);
        PreparedStatement UpDep = null;
        Connection connection = null;
        boolean nombRepetido=false;
        boolean idRepetido = false;
        try {
            Class.forName(driver);
            //Connect to DB
            connection = DriverManager.getConnection(url, user, password);

            int DepId = 0;
            do {
                System.out.println("Introduce el ID del Departamento a modificar");
                DepId = sc3.nextInt();
                idRepetido = existedatoInt(DepId, consDId);
            } while (DepId == 0 || idRepetido == false);

            String Nombre = "";
            String Local = "";
            boolean mira = false;
            do {
                System.out.println("Introduce Nombre:");
                Nombre = sc2.nextLine().toUpperCase();
                nombRepetido = existedatoString(Nombre, consDNombre);
            } while (Nombre.equals("") || nombRepetido == true);
            do {
                System.out.println("Introduce Localizacion:");
                Local = sc2.nextLine().toUpperCase();
            } while (Local.equals("") || Local == null);
            
            UpDep = connection.prepareStatement(modDepto);
            UpDep.setString(1, Nombre);
            UpDep.setString(2, Local);

            UpDep.setInt(3, DepId);
            UpDep.executeUpdate();

        } catch (Exception e) {
        } finally {
            try {
                UpDep.close();
                connection.close();
            } catch (Exception yu) {
            }
        }
    }

    private void ConsDep() {
        Scanner sc2 = new Scanner(System.in);
        PreparedStatement inDep = null;
        Connection connection = null;
        boolean idRepetido = false;
        try {
            Class.forName(driver);
            //Connect to DB
            connection = DriverManager.getConnection(url, user, password);

            String Dempno = "";
            do {
                System.out.println("Introduce Nombre del Deparrtamento a mostrar");
                Dempno = sc2.nextLine().toUpperCase();
                idRepetido = existedatoString(Dempno, consEId);
            } while (Dempno.equals("") || idRepetido == false);
            String depFinal = "%" + Dempno + "%";

            inDep = connection.prepareStatement(consultaDepto);
            inDep.setString(1, depFinal);

            ResultSet rs = inDep.executeQuery();
            int con = 1;
            while (rs.next()) {
                System.out.println(con + ")->\tNumero: " + rs.getInt(1) + ", Nombre: " + rs.getString(2) + ", Localizacion: " + rs.getString(3));
            }
        } catch (Exception e) {
        } finally {
            try {
                inDep.close();
                connection.close();
            } catch (Exception yu) {
            }
        }
    }

    private boolean existedatoString(String dnombre, String compDNombre) {
        PreparedStatement inDep = null;
        Connection connection = null;
        try {
            Class.forName(driver);
            //Connect to DB
            connection = DriverManager.getConnection(url, user, password);
            inDep = connection.prepareStatement(compDNombre);
            inDep.setString(1, dnombre);
            ResultSet rs = inDep.executeQuery();
            if (rs.next()) {
                System.out.println("Introduzca dato correcto o no existente");
                return true;
            }
        } catch (ClassNotFoundException re) {
        } catch (SQLException er) {
        } finally {
            try {
                inDep.close();
                connection.close();
            } catch (Exception yu) {
            }
        }
        return false;
    }

    private boolean existedatoInt(int dato, String sent) {
        PreparedStatement inDep = null;
        Connection connection = null;
        boolean aux = false;
        try {
            Class.forName(driver);
            //Connect to DB
            connection = DriverManager.getConnection(url, user, password);
            inDep = connection.prepareStatement(sent);
            inDep.setInt(1, dato);
            ResultSet rs = inDep.executeQuery();
            if (rs.next()) {
                System.out.println("Dato numero valido");
                return true;
            } else {
                System.out.println("Introduzca dato numerico valido");
            }
        } catch (ClassNotFoundException re) {
        } catch (SQLException er) {
        } finally {
            try {
                inDep.close();
                connection.close();
            } catch (Exception yu) {
            }
        }
        return aux;
    }
}
