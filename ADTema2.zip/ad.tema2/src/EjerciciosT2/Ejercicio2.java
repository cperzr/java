/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EjerciciosT2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Christian
 */
public class Ejercicio2 {

    //jdbc:sqlite:C:\Users\Christian\Desktop\2ºDAM\Acceso a datos\Tema2\SqlLiteyapachederby\ejemplo1.db
    static String sqlite_jdbd_driver = "org.sqlite.JDBC";
    static String prefix = "jdbc:" + "sqlite:";
    static String hostName = "";
    static String urlFolder = "C:\\Users\\Christian\\Desktop\\2ºDAM\\Acceso a datos\\Tema2\\SqlLiteyapachederby\\";
    static String dbName = "ejemplo1.db";

    static String driver = sqlite_jdbd_driver;
    static String url = prefix + hostName + urlFolder + dbName;
    static String user = ""; //"user";
    static String password = ""; //"password";

    public static void main(String[] args) {
        consulta();
    }

    public static void consulta() {
        String query = "SELECT apellido, salario FROM empleados ORDER BY salario desc LIMIT 1;";
        try {
            //Load the driver in RAM
            Class.forName(driver);

            //Connect to DB
            Connection connection = DriverManager.getConnection(url, user, password);
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(query);

            //Iterate on the 'ResultSet' to process each row
            while (result.next()) {//There are still rows to get
                //We get data of each row in the right order: getString, getString, getFloat
                System.out.println(result.getString(1) + " " + result.getFloat(2));
            }

            result.close(); //close ResultSet
            statement.close();//close Statement
            connection.close();//close Connection

        } catch (ClassNotFoundException cnfe) {
            System.out.printf("Not found the jdbc driver %s\n", driver);
        } catch (SQLException sqle) {
            System.out.println("SQL Exception");
        }
    }
}
