/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.


4)Realizar un programa en Java que muestre para cada NOMBRE de departamento el salario medio de sus empleados
    y el SALARIO del empleado con mayor salario


 */
package EjerciciosT2;

import static EjerciciosT2.Ejercicio3.driver;
import static EjerciciosT2.Ejercicio3.statementQueryExample;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Christian
 */
public class Ejercicio4 {

    static String sqlite_jdbd_driver = "org.sqlite.JDBC";
    static String prefix = "jdbc:" + "sqlite:";
    static String hostName = "";
    static String urlFolder = "C:\\Users\\Christian\\Desktop\\2ºDAM\\Acceso a datos\\Tema2\\SqlLiteyapachederby\\";
    static String dbName = "ejemplo1.db";

    static String driver = sqlite_jdbd_driver;

    static String user = ""; //"user";
    static String password = "";

    static String url = prefix + hostName + urlFolder + dbName;

    public static void main(String[] args) {
        statementQueryExample();

    }

    public static void statementQueryExample() {//Nombres y Localización de los departamentos (ordenados
//    alfabéticamente) y para cada departamento, APELLIDO y OFICIO de los empleados que trabajan en cada uno de ellos (ordenados
//   también alfabéticamente)
        String query = "SELECT d.dnombre,(SELECT avg(salario)from empleados e1, departamentos d1 WHERE e1.dept_no=d.dept_no AND d1.dept_no=d.dept_no),(SELECT MAX(e2.salario)FROM empleados e2, departamentos d2 WHERE e2.dept_no=d.dept_no ) FROM empleados e,departamentos d GROUP BY d.dnombre";

        try {
            //Load the driver in RAM
            Class.forName(driver);

            //Connect to DB
            Connection connection = DriverManager.getConnection(url, user, password);

            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(query);
            //Iterate on the 'ResultSet' to process each row
            while (result.next()) {//There are still rows to get
                //We get data of each row in the right order: getInt, getString, getString
                    System.out.println("\n El Departamento" + result.getString(1) + " con salario medio:  " + result.getDouble(2) + " y con salario maximo:"+ result.getDouble(3));
            }

            result.close(); //close ResultSet
            statement.close();//close Statement
            connection.close();//close Connection

        } catch (ClassNotFoundException cnfe) {
            System.out.printf("Not found the jdbc driver %s\n", driver);
        } catch (SQLException sqle) {
            System.out.println("SQL Exception");
        }
    }

}
